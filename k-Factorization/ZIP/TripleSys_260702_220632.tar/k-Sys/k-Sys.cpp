#include <io.h>
#include <iostream>
#include <filesystem>
#include <fstream>
#include "TopGun.h"

#pragma comment(lib, "Utils.lib")

const char* intParamNames[]{
	"nPlayers",
	"nPlayersMax",
	"GroupSize",
	"CBMP_Graph",				// Number of parts in Complete Balanced Multi-Partite Graph (0 or 1 - complete graph, 2 - bipartite, etc.)
	"generateMatrixExample",	// 1 - Construct just one ("generated") factorization (implemented only for CBMP_Graph > 0)
	                            // 0 - Construct all existing factorizations (default) 
	"UseUniform1Factorization",
	"Use2RowsCanonization",
	"UseFastCanonizerForG2",	// 0 currently does not work with u1f
	"SubmatrixGroupOrderMin",
	"ResultGroupOrderMin",
	"USE_GPU",
	"UseMultiThreading",
	"NThreads",
	"KThreads",
	"GThreads",
	"NRowsInStartMatrix",
	"NRowsInResultMatrix",
	"MaxNumberOfStartMatrices",
	"FirstIndexOfStartMatrices",
	"ExpectedResult",
	"UseCheckLinksV",
	"UseRowsPrecalculation",
	"UseSolutionCliquesAfterRow",
	"LastRowSecondPlayer",	// Stop invoking addRow after processing all row solutions for this second player
	"PrintMatrices",
	"SavingMatricesToDisk",
	"MatrixCanonInterval",
	"CheckConstructedMatrices",
	"UseSS",
	"p1f_counter",
	"AutLevelMinDef",	// minimum and maximum numbers of matrix rows for which the 
	"AutLevelMaxDef",	// automorphism groups will be calculated to filter solutions
	"AutLevelMinApp",	// minimum and maximum numbers of matrix rows for which 
	"AutLevelMaxApp",	// solution filtering by automorphism groups will be applied
	"AutDirection",		// Direct (0) or reversed order.  0: G2, G3, ... Gt OR 1: Gt, ..., G3, G2
	"AutGroupsToTest",  // Number of automorphism groups that need to be tested.
	"AutSaveTestedTrs", // 0 - not saving; 1 - saving only while testing on groups ; 
	                    // 2 - saving only while testing paths; 3 - saving while testing on groups OR paths
	"UseImproveMatrix",
	"UseCombinedSolutions",
	"Out_CSV_file",     // 0 - Skip writing output to the CSV file
	                    // 1 - Add SRG info to existing CSV file (create a new file if it does not exist).
	                    // 2 - Write SRG info into a new CSV file.
	"OutAutomorphismGroup",  // 0 - No output, 
	                         // otherwise any combinations of:
	                         //  1,  2 - generators and groups acting on elements
							 //  4,  8 - generators and groups acting on the matrix rows
							 // 16, 32 - generators and groups acting on the k-sets
	"NestedGroups",
	"GridSize",
	"BlockSize",
	"OrderMatrices",
	"AllowUndefinedCycles",		// 1  - allow rows pairs with cycles not defined in input params.
	"Any2RowsConvertToFirst2",
	"ExploreMatrices",			// -8 - No output of integrated results into "ID_Results.txt"
								//  0 - Do not construct graphs
								//  1 (-1) - Construct: SRGs (no canonization)
								//  2 (-2) - Construct: quasi-SRG graphs (no canonization)
								//  4 (-4) -            regular graphs (no canonization)
	"ConstructLatticeGraphs",   
	"SemiSymmetricGraphs",
	"RejectCycleLength",
	"Test",
	"KeepPrevResult",
	"SaveLatinSquareType",
	"InputLatinSquareType",
	"v4", "v4B", "v4C", "v4D",
	"v4Row", "v4RowB", "v4RowC", "v4RowD",
	"UseCompatibilityCheck",
	"HalfRowMode",
	"UseKSolve",
	"UseZStabilizer",
	"TimingOutputMode",     // Write timeStamp into the output file name (default: 0 - out all timing info, 1 - no timing info)
	"CanonizeInput",
};

const char* intArraysParamNames[]{
	"v4Array",
	"NumCommonNeighbors",
};

const char* strParamNames[]{
	"U1FName",
	"StartFolder",
	"ResultFolder",
	"ImprovedResultFolder",
	"UseBinaryCanonizer",
	"TestName",
	"MatrTest",
	"CSV_FileName",     // If such file exists, add new SRG info into the copy of that file
	"ResultsName",
	"InputDataFileName",
};

const char* arrayParamNames[]{
	"U1FCycles"
};

#ifdef USE_CUDA
#define TopGun_GPU TopGunGPU
#else
#define TopGun_GPU TopGun
#endif

using namespace std;

bool getParameters(ifstream& infile, paramDescr* par, int nDescr, kSysParam& param, bool& firstSet, bool& endJob);
bool checkInputParam(const kSysParam& param, const char** paramNames);
string getUF(const tchar* pU1F);

int factorial(int n) {
	return n > 2 ? n * factorial(n - 1) : n;
}

void kSysParam::setup() {
	if (!val[t_CBMP_Graph])
		val[t_CBMP_Graph] = 1;

	const auto groupSize = val[t_groupSize];
	groupSizeFactorial = factorial(groupSize);
	m_numFactors = (val[t_numPlayers] - (completeGraph() ? 1 : partitionSize())) / (groupSize - 1);
}

void enableAnsiColors() {
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	DWORD dwMode = 0;
	GetConsoleMode(hOut, &dwMode);
	SetConsoleMode(hOut, dwMode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
}

void setAutLevels(int *val) {
	auto* pAutLevel = val + t_autLevelMinDef;
	const auto numPlayers = val[t_numPlayers];
	const auto groupSize = val[t_groupSize];
	for (int i = 2; i < 4; i++, pAutLevel++) {
		if (*pAutLevel < i)
			*pAutLevel = i;

		if (!*(++pAutLevel)) {
			*pAutLevel = val[t_nRowsInResultMatrix];
			if (!*pAutLevel)
				*pAutLevel = val[t_CBMP_Graph] > 1 ? numPlayers / groupSize : (numPlayers - 1) / (groupSize - 1);

			if (i == 2 && val[t_nRowsInResultMatrix] > 2)
				--*pAutLevel;
		}
		else {
			if (*pAutLevel < *(pAutLevel - 1))
				*pAutLevel = *(pAutLevel - 1);
		}
	}
}

int main(int argc, const char* argv[])
{
    setvbuf(stdout, NULL, _IONBF, 0);
    g_useColors = _isatty(_fileno(stdout));
#if _DEBUG
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	//_CrtSetBreakAlloc(226);
#endif
	SetConsoleOutputCP(CP_UTF8);
	if (g_useColors) {
		enableAnsiColors();
	}
	cout << "k-Sys 1.03.14.2026\n";
	// Get the handle to the current process
	HANDLE hProcess = GetCurrentProcess();

	// Set the priority class to BELOW_NORMAL_PRIORITY_CLASS
	if (!SetPriorityClass(hProcess, BELOW_NORMAL_PRIORITY_CLASS)) {
		// Handle error if priority setting fails
		printfRed("Can't set priority below normal\n");
		exit(1);
	}
	ifstream* infile = NULL;
	string* testToRun = NULL;
	if (argc > 1) {
		infile = new ifstream(argv[1], ifstream::in);
		if (infile && !infile->is_open()) {
			printfRed("Cannot open file \"%s\"\n", argv[1]);
			delete infile;
			return -1;
		}

		if (argc > 2)
			testToRun = new string(argv[2]);
	}
	else {
		printfRed("Program was launched without parameters.\n");
		return -1;
	}

	auto pathToParam = filesystem::absolute(argv[1]).string();
	auto homePath = filesystem::absolute("./").string();
	std::cout << "Input file with parameters = " << YellowText << pathToParam << ResetTextColor
		      << "\nHome directory = " << YellowText << homePath << ResetTextColor << "\n";
		
	paramDescr params[] = {
		intParamNames, countof(intParamNames), NULL,
		intArraysParamNames, countof(intArraysParamNames), NULL,
		strParamNames, countof(strParamNames), NULL,
		arrayParamNames, countof(arrayParamNames), NULL
	};

	for (auto i = countof(params); i--;)
		params[i].m_pTmpParamStorage = new vector<int>;

	kSysParam param, paramDefault;
	param.pParamDescr = params;
	// Set default integer parameters:
	auto& val = param.val;
	memset(val, 0, sizeof(val));
	val[t_numPlayers] = nPlayers;
	val[t_groupSize] = GroupSize;
	val[t_u1f] = UseUniform1Factorization;
	val[t_use2RowsCanonization] = Use2RowsCanonization;
	val[t_submatrixGroupOrderMin] = SubmatrixGroupOrderMin;
	val[t_resultGroupOrderMin] = ResultGroupOrderMin;
#ifdef USE_CUDA
	val[t_useGPU] = 1;
#else
	val[t_useGPU] = 0;
#endif
	val[t_MultiThreading] = UseMultiThreading;
	val[t_numThreads] = NThreads;
	val[t_numGThreads] = 0;
	val[t_numKThreads] = 1;
	val[t_nRowsInStartMatrix] = NRowsInStartMatrix;
	val[t_nRowsInResultMatrix] = NRowsInResultMatrix;
	val[t_nMaxNumberOfStartMatrices] = MaxNumberOfStartMatrices;
	val[t_nFirstIndexOfStartMatrices] = FirstIndexOfStartMatrices;
	val[t_expectedResult] = ExpectedResult;
	val[t_useCheckLinksV] = UseCheckLinksV;
	val[t_printMatrices] = PrintMatrices;
	val[t_savingMatricesToDisk] = SavingMatricesToDisk;
	val[t_checkConstructedMatrices] = CheckConstructedMatrices;
	val[t_useSS] = UseSS;
	val[t_p1f_counter] = 5000;
	val[t_autLevelMinDef] = val[t_autLevelMin] = NRBase;
	val[t_useImproveMatrix] = UseImproveMatrix;
	val[t_gridSize] = 32;
	val[t_blockSize] = 24;
	val[t_any2RowsConvertToFirst2] = Any2RowsConvertToFirst2;
	val[t_timing_output_mode] = 0;

	// Set default string parameters:
	auto* strVal = param.strVal;
	memset(strVal, 0, t_lastStrParam * sizeof(strVal[0]));

	strVal[t_StartFolder] = new string(StartFolder);
	strVal[t_ResultFolder] = new string(ResultFolder);
	strVal[t_ImprovedResultFolder] = new string(ImprovedResultFolder);
	strVal[t_ResultsName] = new string("_Results");
	strVal[t_InputDataFileName] = new string("");

	for (int i = 0; i < countof(param.u1fCycles); i++)
		param.u1fCycles[i] = 0;

	memcpy(paramDefault.val, param.val, sizeof(paramDefault.val));
	auto* strValDef = paramDefault.strVal;
	strValDef[t_StartFolder] = new string(StartFolder);
	strValDef[t_ResultFolder] = new string(ResultFolder);
	strValDef[t_ImprovedResultFolder] = new string(ImprovedResultFolder);
	strValDef[t_ResultsName] = new string("_Results");
	strValDef[t_InputDataFileName] = new string("");

	initTripleSysData();

	// Job is defined by external file
	vector<string> failedTests;
	auto& testName = strVal[t_testName];
	int numErrors = 0;
	int numTests = 0;
	bool firstSet = true;
	bool endJob = false;
	do {
		if (infile) {
			if (!getParameters(*infile, params, countof(params), param, firstSet, endJob))
				break;
		}

		if (!testToRun || (testName && *testToRun == *testName)) {
			const auto numPlayers = val[t_numPlayers];
			const auto groupSize = val[t_groupSize];
			const auto useGPU = val[t_useGPU];

			const auto dirParam = { t_StartFolder, t_ResultFolder, t_ImprovedResultFolder };
			for (const auto dirIdx : dirParam) {
				auto& dirPath = *strVal[dirIdx];
				if (!dirPath.empty() && dirPath.back() != '\\' && dirPath.back() != '/')
					dirPath += '/';
			}

			char buffer[64];
			if (testName)
				sprintf_s(buffer, "\"%s\" ", testName->c_str());
			else
				buffer[0] = 0;

			printfGreen("Test %sis launched with the following parameters:\n", buffer);
			if (val[t_u1f]) {// && !val[t_exploreMatrices]) {
				if (!val[t_use2RowsCanonization])
					printfYellow(" 1 row canonization %s\n", groupSize > 3 || numPlayers < 12  ? "" : "(can be slow)");
				else
					printfGreen(" 2 rows canonization\n");

				const auto uf_code = param.u1fCycles[0];
				auto& ufName = strVal[t_UFname];
				if (uf_code) {
					ufName = NULL;
					const auto uf = getUF(uf_code);
					if (!ufName) {
						ufName = new string("");
						auto lenCycles = uf_code + 1;
						for (int i = 0; i < *uf_code; i++, lenCycles += MAX_CYCLES_PER_SET) {
							*ufName += '_';
							auto lenCycle = lenCycles;
							while (*lenCycle)
								*ufName += to_string(*lenCycle++);
						}
						if (param.val[t_allowUndefinedCycles])
							*ufName += "_all";
					}
					printfGreen(" %s-matrices with cycles(%s): %s ", getFileNameAttr(&param), ufName->c_str(), uf.c_str());
				}
				else {
					if (!ufName)
						ufName = new string("");
					printfGreen(" %s-matrices with u1f cycles(_all) ", getFileNameAttr(&param));
					//printfGreen(" %s-matrices with p1f cycles(%d) ", getFileNameAttr(&param), numPlayers);
				}
			}
			else {
				printfGreen("%s-matrices ", getFileNameAttr(&param));
			}

			printfGreen("for numPlayers = %d, groupSize = %d using ", numPlayers, groupSize);
			if (!useGPU && val[t_MultiThreading])
				printfGreen("%d CPU threads\n", val[t_numThreads]);
			else
				printfGreen("%cPU\n", useGPU ? 'G' : 'C');

			bool testOK = false;
			const auto np_save = val[t_numPlayers];
			const auto np_saveMax = val[t_numPlayersMax];
			auto np_Max = np_saveMax;
			if (np_Max < np_save)
				val[t_numPlayersMax] = np_Max = np_save;

			for (int np = np_save; np <= np_Max; np += val[t_groupSize]) {
				val[t_numPlayers] = np;
				testOK = checkInputParam(param, intParamNames);
				if (!testOK)
					break;

				setAutLevels(val);
				param.setup();					
				TopGunBase* topGun = useGPU? new TopGun_GPU(param) : new TopGun(param);
				topGun->outputIntegratedResults(NULL, 0);
				if (topGun->Run())
					testOK = false;

				topGun->outputIntegratedResults(params, countof(params));
				delete topGun;
			}

			val[t_numPlayers] = np_save;
			val[t_numPlayersMax] = np_saveMax;

			numTests++;
			if (!testOK) {
				numErrors++;
				failedTests.push_back(testName ? *testName : string("NO_NAME TEST"));
			}
		}

		delete strVal[t_UFname];
		strVal[t_UFname] = NULL;
		for (auto i = countof(params); i--;) {
			auto& tmpParam = params[i].m_pTmpParamStorage;
			for (size_t j = 0; j < tmpParam->size(); j++) {
				const int idx = (*tmpParam)[j];
				switch (i) {
				case t_intValue: param.val[idx] = paramDefault.val[idx]; break;
				case t_intArray: delete[] param.arrVal[idx]; 
					             param.arrVal[idx] = NULL;
								 break;
				case t_strValue: *strVal[idx] = *strValDef[idx]; break;
				case t_strArray: break;   // not implemented
				}
			}
			tmpParam->clear();
		}

		delete testName;
		testName = NULL;
	} while (infile && !endJob);

	if (numErrors) {

		printfRed("The following %d tests failed:\n", numErrors);
		for (int i = 0; i < failedTests.size(); i++)
			printfRed("\"%s\"\n", failedTests[i].c_str());

		wchar_t buffer[64];
		swprintf_s(buffer, L"%d out of %d tests failed", numErrors, numTests);
		speakText(buffer);
	}

	printf("There's nothing left to do.\n");
	speakText(L"There's nothing left to do");

	for (int j = t_lastStrParam; j--;) {
		delete strVal[j];
		delete strValDef[j];
	}

	for (int j = t_lastIntArryParam; j--;) {
		delete[] param.arrVal[j];
	}

	for (int j = params[t_strArray].numParams; j--;)
		for (int i = 0; i < countof(param.u1fCycles); i++)
			delete [] param.u1fCycles[i];

	for (auto i = countof(params); i--;)
		delete params[i].m_pTmpParamStorage;

	delete infile;
	delete testToRun;
	delete TopGun::secondRowDB();

	_CrtDumpMemoryLeaks();

	return numErrors;
}

