#include "TripleSys.h"
#include "k1212_4_20.h"
#include "k1111p1f.h"
#include "k16p1f.h"
#include <iostream>
#include <filesystem>

CC ePrecalculateReturn alldata::endOfRowPrecalculation(eThreadStartMode iCalcMode)
{
	if (m_nPrecalcRows > iDay) {
		m_precalcMode = eCalculateRows;
		m_pRowStorage->init();
	}
	else if (m_nPrecalcRows == iDay) {
		ASSERT_IF(m_secondPlayerInRow4 == 0);
		const bool bCBMP = !completeGraph();
		while (m_secondPlayerInRow4 <= m_secondPlayerInRow4Last) {
			m_secondPlayerInRow4++;
#if 0
			if (m_secondPlayerInRow4 != 7 && m_secondPlayerInRow4 != 10 && m_secondPlayerInRow4 != 14 && m_secondPlayerInRow4 != 17)
				continue;
#endif
			if (bCBMP && !m_groupSizeRemainder[m_secondPlayerInRow4])
				continue;
			if (links(m_secondPlayerInRow4)[0] == unset)
				break;
		}
		if (!m_nRows4Day && m_groupSize == 2)
		{
			m_secondPlayerInRow4 = m_secondPlayerInRow4First;
			bPrevResult = true;
			if (m_nRows4) {
				m_nRows4 = 0;
				if (iCalcMode == eCalculateRows) {
					nLoops = m_nRows4;
					return eNoResult;
				}
				m_pRowUsage->init();
				m_pRowStorage->reset();
			}
			return eContinue;
		}
		m_nRows4Day = 0;
		if (m_secondPlayerInRow4 <= m_secondPlayerInRow4Last)
			return eContinue;
		m_secondPlayerInRow4 = m_secondPlayerInRow4First = 0;
		if (m_nRows4) {
			iDay = m_nPrecalcRows;
			if (m_bPrint)
				printf("Total number of precalculated row solutions = %5d\n", m_nRows4);

			m_lastRowWithTestedTrs = 0;
			if (m_pKSolver) {
				m_precalcMode = eCalculateMatrices; // need to be before solve to correctly check results for canonicity
				m_pKSolver->solve(0);
				return eNoResult;
			}
			
			int mode = -1;
			cnvPrecalcRowsCompCheck(mode);
			m_precalcMode = eCalculateMatrices;

			int iRet = m_pRowStorage->initCompatibilityMasks(m_pRows);

			m_playerIndex = 0;

			if (iRet <= 0) {
#if !USE_CUDA
				if (!iRet) {
					printfRed("*** Unexpected error returned by initCompatibilityMask()\n");
					ASSERT_IF(1);
					exit(101);
				}
#endif
				if (param(t_MultiThreading)) {
					nLoops = 0;
					return eNoResult;
				}
				iDay = m_nPrecalcRows;
				m_precalcMode = eCalculateRows;
				m_pRowStorage->init();
				m_nRows4 = 0;	iDay++;
				//linksFromMatrix(links(), result(), iDay);
				//iPlayer = m_numPlayers;
				bPrevResult = true;
				return eContinue;
			}

			if (iCalcMode == eCalculateRows) {
				nLoops = m_nRows4;
				return eNoResult;
			}
			m_pRowUsage->init();
			//						m_pRowStorage->reset();
			m_nRows4 = 0;
			return eContinue;
		}
	}
	return eOk;
}
CC void alldata::addPrecalculatedRow()
{
	if (!m_nRows4++ && iDay >= 2) {
		TrCycles trc;
		cyclesFor2Rows(m_TrCyclesFirst2Rows, &trc, neighbors(0), neighbors(1), result(0), result(1));
	}

	m_nRows4Day++;
#if 0
	printf("%6d:", m_nRows4);
	printTable("", neighbors(3), 1, m_numPlayers, 2);
	printTable("r", result(3), 1, m_numPlayers, 2);
#endif
#if 0
	bool bP1F = p1fCheck3(result(0), result(m_nPrecalcRows), neighbors(0), neighbors(m_nPrecalcRows));
	if (!bP1F)
		printf("not p1f\n");
	bP1F = p1fCheck3(result(2), result(m_nPrecalcRows), neighbors(2), neighbors(m_nPrecalcRows));
	if (!bP1F)
		printf("not p1f\n");
#endif
	ASSERT_IF(!m_secondPlayerInRow4First);
#if 0
	if (iTest) {
		printTable("r3", result(m_nPrecalcRows), 1, m_numPlayers, m_groupSize);
		if (result(m_nPrecalcRows)[1] == 8)
			iTest = iTest;
	}
#endif
	tchar nb[MAX_PLAYER_NUMBER];
	bool retVal;
	if (m_pKSolver) {
		retVal = m_pKSolver->addRow(m_secondPlayerInRow4, result(m_nPrecalcRows));
	}
	else {
		u1fSetTableRow(nb, result(m_nPrecalcRows), true);
		//printTable("T", result(m_nPrecalcRows), 1, m_numPlayers, m_groupSize);
		retVal = m_pRowStorage->addRow(result(m_nPrecalcRows), neighbors(m_nPrecalcRows), nb);
	}
	if (!retVal) {
		m_playerIndex = m_nPrecalcRows * m_numPlayers;
		goBack();
		m_pRowStorage->init();
		m_secondPlayerInRow4 = m_secondPlayerInRow4First = 0;
		m_playerIndex = 0;
		m_nRows4 = m_nRows4Day = 0;
	}
#if !USE_CUDA
	else if (param(t_useKSolve) & 4) {
		namespace fs = std::filesystem;
		char name[32];
		const auto startMatrix = param(t_nFirstIndexOfStartMatrices);
		if (m_nRows4Day == 1 && m_secondPlayerInRow4 == m_secondPlayerInRow4First) {
			sprintf_s(name, sizeof(name), "./%05d", startMatrix);
			fs::create_directories(name);
			sprintf_s(name, sizeof(name), "./%05d/%05d.txt", startMatrix, startMatrix);
			FOPEN_F(f, name, "w");
			for (int j = 0; j < m_nPrecalcRows; j++) {
				for (int i = 0; i < m_numPlayers; i++)
					fprintf(f, "%3d", result(j)[i]);
				fprintf(f, "\n");
			}
			FCLOSE_F(f);
		}
		sprintf_s(name, sizeof(name), "./%05d/Row%02d.txt", startMatrix, result(m_nPrecalcRows)[1]);
		FOPEN_F(f, name, m_nRows4Day == 1 ? "w" : "a");
		for (int i = 0; i < m_numPlayers; i++)
			fprintf(f, "%3d", result(m_nPrecalcRows)[i]);
		fprintf(f, "\n");
		FCLOSE_F(f);
	}
#endif
}
CC void alldata::initPrecalculationData(eThreadStartMode iCalcMode, int nRowsStart)
{
	m_secondPlayerInRow4First = 0;
	m_nPrecalcRows = param(t_useRowsPrecalculation);
	if (iCalcMode == eCalcSecondRow) {
		iCalcMode = eCalcResult;
		m_numDaysResult = 2;
		nRowsStart = m_nPrecalcRows = 0;
	}
	if (iCalcMode == eCalcResult)
		m_precalcMode = (m_nPrecalcRows && m_nPrecalcRows <= 4 && m_groupSize <= 3 && nRowsStart <= m_nPrecalcRows) ? eCalculateRows : eDisabled;
	else
		m_precalcMode = iCalcMode;

	tchar secondPlayerMax = m_numPlayers - (m_groupSize == 2 ? 1 : (m_groupSize + 1 + m_numDays - m_numDaysResult));
	const bool bCBMP = !completeGraph();
	if (bCBMP) {
		secondPlayerMax = m_numPlayers - 1 - (m_groupSize - 2) * m_groupSize;
	}
	m_secondPlayerInRow4Last = MIN2(param(t_lastRowSecondPlayer), secondPlayerMax);
	if (!m_secondPlayerInRow4Last)
		m_secondPlayerInRow4Last = m_groupSize == 2 ? (bCBMP ? m_numDaysResult * 2 - 1 : m_numDaysResult) : secondPlayerMax;

	m_nRows4Day = m_nRows4 = m_secondPlayerInRow4 = 0;
#if 1 // preset automorphism groups
	const auto iCalc = m_precalcMode;
	m_precalcMode = eCalcResult;
	if (!param(t_autGroupNumb)) {
		if (m_nPrecalcRows > 1 && iDay >= m_nPrecalcRows) {
			auto* pGroupInfo = groupInfo(m_nPrecalcRows);
			if (pGroupInfo) {
				cnvCheckNew(0, m_nPrecalcRows, false); // create initial set of tr for first i rows
				pGroupInfo->copyIndex(*this);
				resetGroupOrder();
			}
		}
	}
	else {
		for (int i = firstGroupIdx(); i <= lastGroupIdx(); i++) {
			auto* pGroupInfo = groupInfo(i);
			if (!pGroupInfo)
				break;
			if (iDay < i)
				break;
			cnvCheckNew(0, i, false); // create initial set of tr for first i rows
			pGroupInfo->copyIndex(*this);
			resetGroupOrder();
		}
	}
	m_precalcMode = iCalc;
#endif
}
