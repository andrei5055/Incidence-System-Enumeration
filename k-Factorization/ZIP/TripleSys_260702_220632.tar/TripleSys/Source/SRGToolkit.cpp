﻿#include "SRGSupport.h"
#include "SRGToolkit.h"
#include <cstring>
#include <mutex>

#pragma execution_character_set("utf-8")

#define PERMUT			1
#define USE_COMPLEMENT -1   // -1 use compliment graph only when 2*k > v
                            //  0 don't use compliment graph
                            //  1 always use complement graph
                             

using namespace std;

// Use PERMUT equal 
//    0 to find the automorphism of original matrix (it will be in vvv.txt)
//    1 to find the automorphism of canonized complement matrix
#if PRINT_NUM_CUR_GRAPH && PRINT_MATRICES && PERMUT
ushort autIni[] = {  // Could be found in vvv.txt
#if N_MATR == 3
#if NUM_GENERATOR == 1
	 0, 34, 18, 17, 32, 47, 13,  7, 23, 43, 20, 41, 31,  6, 35, 37, 29,  3,  2, 25,
	10, 21, 44,  8, 46, 19, 26, 40, 28, 16, 36, 12,  4, 33,  1, 14, 30, 15, 48, 45,
	27, 11, 42,  9, 22, 39, 24,  5, 38
#elif NUM_GENERATOR == 2
	19, 46, 21, 26, 44, 40,  8,  7,  6, 41, 23, 31, 43, 20, 34, 32, 47, 17, 18,  0,
	13,  2, 37, 10, 35, 25,  3, 29, 48, 27, 30, 11, 15, 45, 14, 24, 42, 22, 38, 39,
	 5,  9, 36, 12,  4, 33,  1, 16, 28
#endif
#elif N_MATR == 5
	41, 40, 37, 39, 35, 36, 38, 23, 26, 24, 25, 27, 22, 21, 48, 45, 43, 47, 42, 44,
	46, 13, 12,  7,  9, 10,  8, 11, 29, 28, 33, 32, 31, 30, 34,  4,  5,  2,  6,  3,
	 1,  0, 18, 16, 19, 15, 20, 17, 14
#endif
};

ushort autLost[] = {
#if N_MATR == 3
#if NUM_GENERATOR == 1
	 0,  7,  9, 13, 11, 17, 15,  1,  8,  2, 10,  4, 12,  3, 14,  6, 18,  5, 16, 23,
	29, 27, 43, 19, 30, 25, 45, 21, 47, 20, 24, 33, 41, 31, 48, 35, 39, 46, 40, 36,
	38, 32, 44, 22, 42, 26, 37, 28, 34
#endif
#elif N_MATR == 5
	29, 30,  8,  7, 43, 45, 47,  3,  2, 12, 20, 21,  9, 38, 33, 42, 31, 39, 35, 22,
	10, 11, 19, 40, 32, 37, 36, 41, 34,  0,  1, 16, 24, 14, 28, 18, 26, 25, 13, 17,
	23, 27, 15,  4, 48,  5, 46,  6, 44
#endif
};
#endif

static bool one_common_element(ctchar* pArray1, ctchar* pArray2, int len) {
	int i = 0, j = 0;
	while (i < len && j < len) {
		if (pArray1[i] == pArray2[j])
			return true;

		if (pArray1[i] < pArray2[j])
			++i;
		else
			++j;
	}
	return false;
}

void reportNestedGroupCheckResult(int retVal, bool outToScreen) {
	if (retVal > 0) {
		printfRed("Nested groups check failed on row %d\n", retVal);
		myExit(1);
	}
	else {
		if (outToScreen && !retVal)
			printfGreen("Nested groups check OK\n");
	}
}

string currentGraphParam;


SRGToolkit::SRGToolkit(const kSysParam* p, int nRows, const string& resFileName, int exploreMatrices, SRGToolkit* pMaster, TopGunBase* pTopGunBase) :
	m_pParam(p), m_nRows(nRows), m_nExploreMatrices(exploreMatrices),
	CGraphCanonizer(nRows * p->val[t_numPlayers] / p->val[t_groupSize]) {
	m_pMaster = pMaster;
	m_pTopGunBase = pTopGunBase;
	setOutFileName(NULL);
	const int coeff = PRINT_MATRICES ? 3 : 0;
	m_subgraphVertex = new ushort[groupDegree()];
	for (int i = 0; i < 2; i++) {
		m_nNumCommonMax[i] = 1;
		m_bChekMatr[i] = true;
		m_pGraphParam[i] = new SRGParam();
		m_resFileName[i] = resFileName;
#if OUT_SRG_TO_SEPARATE_FILE
		char buf[32], *pBuf = buf;
		SPRINTFD(pBuf, buf, "%d_matrices.txt", i + 1);
		m_resFileName[i] += buf;
#endif	
	}

	if (p->arrVal) {
		const auto pCommon = p->arrVal[t_numCommonNeighbors];
		if (pCommon) {
			for (int i = 0; i < pCommon[0]; i++)
				m_nNumCommonMax[i] = pCommon[i + 1];
		}
	}

	m_pParam_ICN = new ICNParam[numICN_param()];
}

SRGToolkit::~SRGToolkit() {
	setOutFileName(NULL);
	delete[] m_subgraphVertex;
	delete[] outFileName();
	for (int i = 0; i < 2; i++)
		delete m_pGraphParam[i];

	delete[] m_pParam_ICN;
}

bool SRGToolkit::exploreMatrix(ctchar* pMatr, uint sourceMatrID, CBinaryMatrixStorage** ppMarixStorage) {
	int counter = 0;
	m_bFactorizationOutputCompleted = false;
	for (int i = 0; i < 2; i++) {
		if (!m_bChekMatr[i])
			continue;

		if (!exploreMatrixOfType(i, pMatr, sourceMatrID, ppMarixStorage[i])) {
			delete m_pGraphParam[i];
			m_pGraphParam[i] = NULL;
			m_bChekMatr[i] = false;
		} else
			counter++;
	}

	return counter > 0;
}

void SRGToolkit::buildGraph(ctchar* pMatr, tchar* pAdjacencyMatrix, int typeIdx) const
{
	const auto groupSize = m_pParam->paramVal(t_groupSize);
	const auto nCols = m_pParam->paramVal(t_numPlayers);
	const auto numGroups = nCols / groupSize;
	const auto pVertexLast = pMatr + m_nRows * nCols;
	const auto cond = typeIdx != 0;
	const auto mult = cond ? groupSize : numGroups - groupSize;
	const auto v = groupDegree();

	int numVertex = 0;
	auto pVertex = pMatr;
	for (int i = 0; i < m_nRows; i++) {
		for (int j = 0; j < numGroups; j++, pVertex += groupSize, numVertex++) {
			// Add edges to the graph for the vertices in the same matrix row
			auto numNextVertex = numVertex;
			for (int k = j; ++k < numGroups;) {
				++numNextVertex;
				pAdjacencyMatrix[numVertex * v + numNextVertex] =
					pAdjacencyMatrix[numNextVertex * v + numVertex] = 1;
			}

			// Add edges between vertex pairs whose corresponding tuples of size `groupSize`
			// either share exactly one common element (if `cont == true`)
			// or have no elements in common (if `cont == false`).
			int nConnected = (m_nRows - i - 1) * mult;
			auto* pNextVertex = pMatr + (i + 1) * nCols;
			while (pNextVertex < pVertexLast) {
				numNextVertex++;
				// We do have two pointers (pVertex and pNextVertex).
				// If one out of groupSize elements is the same, then we have an edge between two vertices.
				if (one_common_element(pVertex, pNextVertex, groupSize) == cond) {
					// Add edges to the graph for the vertices intersecting by one element
					pAdjacencyMatrix[numVertex * v + numNextVertex] =
						pAdjacencyMatrix[numNextVertex * v + numVertex] = 1;

					if (!(--nConnected))
						break;
				}

				// Move to the next vertex
				pNextVertex += groupSize;
			}
		}
	}
}

bool SRGToolkit::exploreMatrixOfType(int typeIdx, ctchar* pMatr, uint sourceMatrID, CBinaryMatrixStorage *pMarixStorage) {
	const auto groupSize = m_pParam->paramVal(t_groupSize);
	if (!typeIdx) {
		// Check whether the graph is Triangular or Rock graph
		if (groupSize == 2 && m_pParam->partiteNumb() <= 2 && !m_pParam->paramVal(t_constructLatticeGraphs)) {
			unique_lock<mutex> guard;
			if (auto* mtx = pMarixStorage->getMutext())
				guard = unique_lock<mutex>(*mtx);

			const auto graphType = m_pParam->partiteNumb() == 1 ? t_triangular : t_rock;
			pMarixStorage->graphDB()->setGraphType(graphType);

			// Output of the parameters for graphs that will not be constructed.
			SRGParam graphParam;
			int n = 0;
			switch (graphType) {
			case t_triangular: // (v, k, λ, μ) = (n(n-1)/2, 2(n-2), n-2, 4)
				n = static_cast<uint32_t>(
					sqrt(static_cast<double>(1 + 8 * numVertices())));
				n = (1 + n) / 2;
				graphParam.k = 4 * (n - 2);
				graphParam.μ = 4;
				break;
			case t_rock:		//  (v, k, λ, μ) = (n^2, 2(n−1), n−2, 2)
				n = static_cast<uint32_t>(
					sqrt(static_cast<double>(numVertices())));
				graphParam.k = 2 * (n - 1);
				graphParam.λ = n - 2;
				graphParam.μ = 2;
			default: break;
			}

			// λ, α and β are calculated identicaly for both families of graphs:
			graphParam.λ = n - 2;
			graphParam.α = (n - 2) * (n - 3) / 2;
			graphParam.β = 0;
			currentGraphParam = format("(v,k,λ,μ) = ({},{:2},{},{}),  (α,β) = ({},{})",
				numVertices(), graphParam.k, graphParam.λ, graphParam.μ, graphParam.α, graphParam.β);

			return false;
		}
	}

	if (reportOnScreen())
		cout  << "\n" << " Exploring graph type " << (typeIdx + 1) << " for matrix #" << sourceMatrID << "\n";

	const auto nCols = m_pParam->paramVal(t_numPlayers);
	const auto numGroups = nCols / groupSize;
	const auto pVertexLast = pMatr + m_nRows * nCols;

	auto graphParam = m_pGraphParam[typeIdx];
	const auto cond = typeIdx != 0;
	const auto mult = cond ? groupSize : numGroups - groupSize;
	// Create graph
	auto pAdjacencyMatrix = graphPntr(0);
	memset(pAdjacencyMatrix, 0, lenGraphMatr() * sizeof(pAdjacencyMatrix[0]));
#if 1
	buildGraph(pMatr, pAdjacencyMatrix, typeIdx);
#else
	void triangularGraph(tchar N, tchar * A, bool verifyMatrix = false);
	if (typeIdx)
		return false;

	triangularGraph(nCols, pAdjacencyMatrix);
#endif
	const auto graphType = checkSRG(pAdjacencyMatrix, graphParam);
	unique_lock<mutex> guard;
	if (auto* mtx = pMarixStorage->getMutext()) {
		guard = unique_lock<mutex>(*mtx);
		auto* pGrParam = getMaster()->graphParam(typeIdx);
		if (!pGrParam->k) {
			// Save the parameters of the graph, but not counters.
			pGrParam->k = graphParam->k;
			pGrParam->λ = graphParam->λ;
			pGrParam->μ = graphParam->μ;
			pGrParam->α = graphParam->α;
			pGrParam->β = graphParam->β;
		}
	}

	pMarixStorage->graphDB()->setGraphType(graphType);

	int flg = 1;
	switch (graphType) {
	case t_nonregular:
	case t_complete:  return false;
	case t_quasi_srg: flg = 2; break;
	case t_regular:   flg = 4;
	}

	const bool canonize = m_nExploreMatrices > 0;
	if (!((canonize ? m_nExploreMatrices : -m_nExploreMatrices) & flg))
		return false;

	bool rank3 = false;
	tchar* pGraph[2] = { NULL, NULL };
	tchar* pUpperDiag = NULL;
	ctchar* pResGraph = NULL;
	if (canonize) {
		const auto v = groupDegree();
		int i = 0;
		// Copy elements above the main diagonal into the array.
		auto pFrom = pResGraph = canonize_graph(NULL, &i);
		auto pTo = pUpperDiag = graphPntr(1 - i);
		for (int j = v, i = 0; --j; pTo += j, pFrom += v)
			memcpy(pTo, pFrom + ++i, j);

		// Copying vertex orbits and trivial permutation
		auto pntr = this->getObject(0);
		auto *pGroupOrb = groupOrbits();
		memcpy(pntr, pGroupOrb, v * sizeof(*pntr));
		pntr += 2 * (i = v);
		rank3 = true;
		while (i--) {
			pntr[i] = i;
			if (rank3)
				rank3 = !pGroupOrb[i];
		}

		// Analyze the stabilizer of first vertex
		pntr -= v;
		const auto j = graphParam->k + 1;
		for (i = 1; i < j; i++)
			rank3 &= pntr[i] == 1;

		while (i < v && rank3)
			rank3 = pntr[i++] == j;

#if PRINT_NUM_CUR_GRAPH && PRINT_MATRICES
		if (printFlag) {
			// pInitOrbits - permutation, that canonize original matrix
			const auto ppp = pResOrbits + m_v;
			ushort s[49];
#if PERMUT
			// Convert it to the automorphism of the original matrix 
			// Using ChatGPT suggestion https://chatgpt.com/share/68ab681a-aa0c-8010-a03d-7c9afb22af14
			// s = q∘p∘q^−1.
			// Note: q^−1 is in ppp = pResOrbits + m_v

			for (int j = m_v; j--;)
				pResOrbits[j] = ppp[autIni[j]];

			for (int j = m_v; j--;)
				s[j] = pResOrbits[pInitOrbits[j]];

			createGraphOut(pResGraph, pGraph[1], 0, 0, s);
			assert(!memcmp(pResGraph, pGraph[1], m_lenGraphMatr * sizeof(*pGraph[0])));
			PRINT_ADJ_MATRIX(pGraph[1], 0, v, s, "vvv");

			ASSERT_IF(canonizeGraph(m_pGraph[i], m_pGraph[1 - i], 0));
#else
			pntr += (NUM_GENERATOR + 1) * v;  // pointer to the first non-trivial generator
			// Check if it's an automorphism
			createGraphOut(pResGraph, pGraph[1], 0, 0, pntr);
			assert(!memcmp(pResGraph, pGraph[1], m_lenGraphMatr * sizeof(*pGraph[0])));

			// Multiply this automorphism by pInitOrbits
			for (int j = m_v; j--;)
				pResOrbits[j] = pInitOrbits[pntr[j]];

			for (int j = m_v; j--;)
				pInitOrbits[pResOrbits[j]] = j;

			createGraphOut(pResGraph, pGraph[1], 0, 0, pInitOrbits);
			PRINT_ADJ_MATRIX(pGraph[1], 0, v, pInitOrbits, "zzz");
			assert(!memcmp(pGraph[0], pGraph[1], m_lenGraphMatr * sizeof(*pGraph[0])));

			// Using ChatGPT suggestion https://chatgpt.com/share/68ab681a-aa0c-8010-a03d-7c9afb22af14
			// multiply q (saved in pResOrbits + m_v) by p^(-1) (which is pInitOrbits)
			// s=q∘p^−1
#define	A	1
#if A
			const auto q = ppp;
			const auto p = pInitOrbits;
#else
			const auto q = pInitOrbits;
			const auto p = ppp;
#endif
			for (int j = m_v; j--;)
				pResOrbits[p[j]] = j;   // pResOrbits is p^(-1)

			for (int j = m_v; j--;)
				s[j] = pResOrbits[q[j]];

			// Obtained permutation (pResOrbits) should be an automorphism of pGraph[0]
			// Let's check it
			createGraphOut(pGraph[0], pGraph[1], 0, 0, s);
			assert(!memcmp(pGraph[0], pGraph[1], m_lenGraphMatr * sizeof(*pGraph[0])));
			PRINT_ADJ_MATRIX(pGraph[1], 0, m_v, s, "vvv");
#endif
		}
#endif
	}

	bool newGraph = false;
	{
		SRGToolkit* pMaster = this;
		unique_lock<mutex> guard;
		if (auto* mtx = pMarixStorage->getMutext()) {
			guard = unique_lock<mutex>(*mtx);
			(pMaster = getMaster())->setGroupOrder(groupOrder());
		}

		newGraph = pMaster->outputGraph(typeIdx, graphType, sourceMatrID, pMarixStorage, rank3, pResGraph, pUpperDiag, this);
	}

	if (!newGraph) {
		// Graph is isomorphic to a previously constructed one — adjust statistics to avoid duplicate counting.
		--graphParam->m_cntr[0];
		--graphParam->m_cntr[1];
		if (graphType != t_regular)
			--graphParam->m_cntr[2];

		if (graphType == t_4_vert)
			--graphParam->m_cntr[3];
	}
	else {
		if (rank3)
			graphParam->m_cntr[4]++;
	}

	return true;
}

bool SRGToolkit::outputGraph(int typeIdx, t_graphType graphType, uint sourceMatrID, CBinaryMatrixStorage* pMarixStorage, 
	bool rank3, ctchar *pResGraph, ctchar* pUpperDiag, SRGToolkit *pSlaveToolKit)
{
	if (this != pSlaveToolKit) {
		// Output of factorization matrix
		// It needs to be here only if SRA Toolkit::explorer Matrix is ​​invoked in multi-threaded mode;
		pSlaveToolKit->outputMatrix(sourceMatrID);
	}

	bool newGraph = true;
	int idxMatr = 0, prevMatrNumb = m_nPrevMatrNumb;
	if (pUpperDiag) {
		// We are here only if the graph was canonized. 
		// Let's check if this graph is isomorphic to a previously constructed one.
		prevMatrNumb = pMarixStorage->numObjects();
		idxMatr = pMarixStorage->updateRepo(pUpperDiag);
		newGraph = prevMatrNumb < pMarixStorage->numObjects();
	}
	else
		m_nPrevMatrNumb++;

	auto graphParam = m_pGraphParam[typeIdx];
	if (newGraph)
		outputGraph(typeIdx, prevMatrNumb, graphType, rank3, pResGraph, pSlaveToolKit);

	const char* pGraphDescr = "";
	if (rank3)
		pGraphDescr = "rank 3 graph";
	else
		if (graphType == t_4_vert)
			pGraphDescr = "4-vertex condition";

	const auto v = groupDegree();
	char buf[512], * pBuf = buf;
	if (graphType != t_regular)
		SPRINTFD(pBuf, buf, "Strongly regular graphs with parameters: (v,k,λ,μ) = (%d,%2d,%d,%d)",
			v, graphParam->k, graphParam->λ, graphParam->μ);
	else
		SPRINTFD(pBuf, buf, "Regular graphs with parameters: (v,k) = (%d,%2d)", v, graphParam->k);

	auto pGraphDB = pMarixStorage->graphDB();
	pGraphDB->setTableTitle(buf);
	const auto graphIdx = newGraph ? pMarixStorage->numObjects() : pMarixStorage->getObjectID(-idxMatr - 1) + 1;
	GraphType graphDescr(pGraphDescr, graphIdx);
	pGraphDB->addObjDescriptor(groupOrder(), &graphDescr, newGraph, sourceMatrID + 1);

	//	PRINT_ADJ_MATRIX(pResGraph, m_pMarixStorage[typeIdx]->numObjects(), m_v);
	return newGraph;
}

void SRGToolkit::outputGraph(int typeIdx, uint prevMatrNumb, t_graphType graphType, bool rank3, ctchar *pResGraph, SRGToolkit* pSlaveToolKit)
{
	// New SRG constructed
	setOutFileName(m_resFileName[typeIdx].c_str());

	FOPEN_F(f, outFileName(), prevMatrNumb || !OUT_SRG_TO_SEPARATE_FILE ? "a" : "w");
	SrgSummary srgSummary(m_pParam->strVal[t_ResultFolder], param(t_out_CSV_file), m_pParam->strVal[t_CSV_FileName]);
	char buf[512], * pBuf = buf;
	const auto v = groupDegree();
	auto graphParam = m_pGraphParam[typeIdx];
#if OUT_SRG_TO_SEPARATE_FILE
	if (!prevMatrNumb) {
		if (graphType != t_regular)
			fprintf(f, "List of SRGs of type %d with parameters (v,k,λ,μ) = (%d,%2d,%d,%d):\n", typeIdx + 1, numVertices(), graphParam->k, graphParam->λ, graphParam->μ);
		else
			fprintf(f, "List of regular graphs of type %d with parameters (v,k) = (%d,%2d):\n", typeIdx + 1, numVertices(), graphParam->k);
	}

	SPRINTFD(pBuf, buf, ORDER_FRMT("\nGraph #%d:  |Aut(G)| = ", ""), prevMatrNumb + 1, GR_ORDER(groupOrder()));
#else
#if PRINT_NUM_CUR_GRAPH
	SPRINTFD(pBuf, buf, "\n  *** numCurrGraph = %d ***", numCurrGraph);
#endif
	if (graphType != t_regular)
		SPRINTFD(pBuf, buf, "\nSRG #%d of type %d with parameters (v,k,λ,μ) = (%d,%2d,%d,%d):",
			prevMatrNumb + 1, typeIdx + 1, v, graphParam->k, graphParam->λ, graphParam->μ);
	else
		SPRINTFD(pBuf, buf, "\nRegular graph #%d of type %d with parameters (v,k) = (%d,%2d):",
			prevMatrNumb + 1, typeIdx + 1, v, graphParam->k);

	SPRINTFD(pBuf, buf, ORDER_FRMT(" |Aut(G)| =", ""), GR_ORDER(groupOrder()));
	if (groupOrder() > 1) {
		const auto primeFactor = getPrimeFactorization(groupOrder());
		SPRINTFD(pBuf, buf, "= %s", g_useColors? printWithPowers(primeFactor).c_str() : primeFactor.c_str());
	}

	if (reportOnScreen())
		cout << buf << "\n";
#endif
	if (rank3)
		SPRINTFD(pBuf, buf, "\nIt's a rank 3 graph with");
	else
		if (graphType == t_4_vert)
			SPRINTFD(pBuf, buf, "\n4-vertex condition satisfied");


	if (rank3 || graphType == t_4_vert)
		SPRINTFD(pBuf, buf, " (α, β) = (%d, %d)", graphParam->α, graphParam->β);

	if (graphType != t_regular) {
		const bool canonize = m_nExploreMatrices > 0;
		const auto rank3graph = rank3 ? 1 : (canonize ? -1 : 0);
		const auto grOrder = canonize ? groupOrder() : 0;
		const auto groupSize = m_pParam->paramVal(t_groupSize);
		const auto nCols = m_pParam->paramVal(t_numPlayers);
		srgSummary.outSRG_info(v, graphParam, graphType, rank3graph, grOrder, groupSize, nCols / groupSize, m_srcGroupOrder);
	}

	fprintf(f, "%s\n", buf);
	if (pResGraph)
		outAdjMatrix(pResGraph, f);

	FCLOSE_F(f);

	if (pResGraph && groupOrder() > 1) {
		pSlaveToolKit->setOutFileName(outFileName());
		pSlaveToolKit->makeGroupOutput(NULL, false, false);
	}
}

t_graphType SRGToolkit::checkSRG(tchar* pGraph, SRGParam* pGraphParam) {
	if (pGraphParam)
		pGraphParam->m_cntr[0]++;

	// Check if constructed graph is regular
	int graphDegree = 0;
	auto pVertex = pGraph;
	const auto v = groupDegree();
	for (int i = 0; i < v; i++, pVertex += v) {
		int vertexDegree = 0;
		for (int j = 0; j < v; j++)
			if (pVertex[j])
				vertexDegree++;

		if (graphDegree) {
			if (graphDegree != vertexDegree) {
				printfRed("Graph is not regular\n");
				return t_nonregular;
			}
		}
		else
			graphDegree = vertexDegree;
	}

	bool flag;
	// Check if constructed graph is strongly regular
	const auto graphType = checkSRG(pGraph, graphDegree, flag);
	switch (graphType) {
	case t_regular: 
		if (pGraphParam && !pGraphParam->m_cntr[1]++)
			pGraphParam->k = graphDegree;
	case t_complete:return graphType;

	default: // Check if complementary graph is a complete graph or a set of complete graphs 
		if (graphDegree == v - 1 || graphDegree == m_pParam_ICN[1].numCommon)
			return t_complete;
	}

#if USE_COMPLEMENT != 0
	if (USE_COMPLEMENT == 1 || 2 * graphDegree > v && graphDegree < v - 1) {
		graphDegree = v - 1 - graphDegree;
		// Compute the complement graph by inverting the adjacency relations.
		auto pVertex = pGraph;
		for (int i = 0; i < v; i++, pVertex += v) {
			for (int j = 0; j < v; j++)
				pVertex[j] = 1 - pVertex[j];

			pVertex[i] = 0;
		}
		checkSRG(pGraph, graphDegree, flag);
		printfYellow_TGO("\ncomplement\n");
	}
	else
		printfYellow_TGO("\nNot complement (because of type)\n");
#else
	printfYellow_TGO("\nNot complement (n/a)\n");
#endif

	if (pGraphParam && !pGraphParam->m_cntr[1]++)
		pGraphParam->k = graphDegree;

	return pGraphParam->updateParam(m_pParam_ICN, flag);
}

t_graphType SRGToolkit::checkSRG(const tchar *pGraph, int graphDegree, bool &flag) {
	graphDegree--;
	memset(m_pParam_ICN, 0, numICN_param() * sizeof(ICNParam));
	memset(m_nNumCommon, 0, sizeof(m_nNumCommon));
	flag = true;
	auto pFirstVertex = pGraph;
	const auto v = groupDegree();
	for (int i = 0; i < v; i++, pFirstVertex += v) {
		auto pSecondVertex = pFirstVertex;
		for (int j = i; ++j < v;) {
			pSecondVertex += v;
			int nCommonCurr, alpha;
			for (int k = nCommonCurr = alpha = 0; k < v; k++) {
				if (pFirstVertex[k] && pSecondVertex[k])
					m_subgraphVertex[nCommonCurr++] = k;
			}

			if (flag) {
				if (nCommonCurr == graphDegree)
					return t_complete;   // Complete graph, we don't need them

				// Count the number of edges in the subgraph of two vertices common neighbors 
				for (int k = 0; k < nCommonCurr; k++) {
					for (int l = k + 1; l < nCommonCurr; l++) {
						if (pGraph[m_subgraphVertex[k] * v + m_subgraphVertex[l]])
							alpha++;
					}
				}
			}

			const auto idx = pFirstVertex[j] ? 0 : m_nNumCommonMax[0];
			const auto iMax = idx ? m_nNumCommonMax[1] : m_nNumCommonMax[0];
			int i = -1;
			ICNParam *pParam = m_pParam_ICN + idx;
			while (++i < iMax && pParam->numCommon && pParam->numCommon != nCommonCurr)
				pParam++;

			if (i == iMax) {
#if 0
				printfRed("Graph is not %sstrongly regular:\n", m_nNumCommonMax[0] == 1 && m_nNumCommonMax[1] > 1? "quasi-" : "");
				printfRed("For(%d, %d) %s is %d\n", i, j, idx ? "mu" : "lambda", nCommonCurr);
				pParam = m_pParam_ICN + idx;
				for (i = 0; i < iMax; i++, pParam++)
					printfRed("  ... and not %d as it was for (%d, %d)\n", pParam->numCommon, pParam->vertice[0], pParam->vertice[1]);

				PRINT_ADJ_MATRIX(pGraph);
#endif
				return t_regular;
			}

			if (pParam->numCommon) {
				if (flag) {
					flag = !i && (pParam->numEdges == alpha);
#if 0
					if (!flag) {
						printfRed("Graph does not satisfy 4-vertex condition\n"
							"For (%d, %d) %s is %d and not %d as it was for (%d, %d)\n",
							i, j, idx ? "β" : "α", alpha, pParam->numEdges, pParam->vertice[0], pParam->vertice[1]);
						PRINT_ADJ_MATRIX(pGraph);
					}
#endif
				}
			} else {
				pParam->numCommon = nCommonCurr;
				pParam->numEdges = alpha;
				pParam->vertice[0] = i;
				pParam->vertice[1] = j;
			}
		}
	}

	return m_nNumCommon[0] == 1 && m_nNumCommon[1] == 1 ? t_srg : t_quasi_srg;
}

t_graphType SRGParam::updateParam(const ICNParam* pCommon, bool flag_4_ver) {
	if (this) {
		if (flag_4_ver) {
			if (α && α != pCommon[0].numEdges || β && β != pCommon[1].numEdges)
				printfRed("Found graph with 4-vertex condition for different (α, β) = (%d, %d) != (%d, %d)\n",
					pCommon[0].numEdges, pCommon[1].numEdges, α, β);
			α = pCommon[0].numEdges;
			β = pCommon[1].numEdges;
			m_cntr[3]++; // # of graphs satisfying 4-vertex condition
		}

		if (!m_cntr[2]++) {
			λ = pCommon[0].numCommon;
			μ = pCommon[1].numCommon;
		}
	}
	return flag_4_ver ? t_4_vert : t_srg;
}

void SRGToolkit::printStat() {
	const auto v = groupDegree();
	for (int i = 0; i < 2; i++) {
		if (!m_pGraphParam[i])
			continue;

		auto& graphParam = *m_pGraphParam[i];
		if (!m_bChekMatr[i]) {
			printfRed("At least one out of %d graphs of type %d is not SRG.\n", graphParam.m_cntr[0], i);
			//continue;
		}

		const bool plural = graphParam.m_cntr[0] > 1;
		const char* pntr0 = plural ? "s" : "";
		const char* pntr1 = plural ? "are" : "is";

		printfYellow("\nConstructed %d graph%s of type %d with %d vertices\n", graphParam.m_cntr[0], pntr0, i + 1, v);
		if (!graphParam.m_cntr[2]) {
			printfYellow(" • %d %s regular of degree %d\n", graphParam.m_cntr[1], pntr1, graphParam.k);
			continue;
		}

		unsigned int n4VertCond;
		int a = -1, b = -1;
		if (graphParam.m_cntr[4]) {
			printfYellow(" • %d - rank 3 graph%s\n", graphParam.m_cntr[4], (graphParam.m_cntr[4] > 1 ? "s" : ""));
			n4VertCond = graphParam.m_cntr[4] - graphParam.m_cntr[3];
			if (n4VertCond) {
				printfRed(" • %d graph%s satisf%s 4-vertex conditions: (α = %d, β = %d)\n",
					n4VertCond, (n4VertCond > 1 ? "s" : ""), (n4VertCond > 1 ? "y" : "ies"), graphParam.α, graphParam.β);
				a = graphParam.α;
				b = graphParam.β;
			}
		}
		else {
			n4VertCond = graphParam.m_cntr[3];
			if (n4VertCond) {
				printfYellow(" • %d graph%s satisf%s 4-vertex conditions: (α = %d, β = %d)\n",
					n4VertCond, (n4VertCond > 1 ? "s" : ""), (n4VertCond > 1 ? "y" : "ies"), graphParam.α, graphParam.β);
				a = graphParam.α;
				b = graphParam.β;
			}
		}
		printfYellow(" • %d %s strongly regular with parameters: (v, k, λ, μ) = (%d,%2d,%d,%d)\n",
			graphParam.m_cntr[2], pntr1, v, graphParam.k, graphParam.λ, graphParam.μ);
		const auto v_2k = v - 2 * graphParam.k;
		const auto k = v - graphParam.k - 1;
		const auto λ = v_2k + graphParam.μ - 2;
		const auto μ = v_2k + graphParam.λ;
		//graphParam.α = λ * (λ - 1) / 2 - graphParam.α;
		//graphParam.β = μ * (μ - 1) / 2 - graphParam.β;
		printfYellow("Complementary graph parameters: (v, k, λ, μ) = (%d,%2d,%2d,%2d)\n", v, k, λ, μ);
		const auto α = graphParam.k - graphParam.β;
		const auto β = v_2k + graphParam.μ - graphParam.α - 2;
		//if (n4VertCond)
		//	printfYellow("            4-vertex condition parameters: (%d, %d)\n",  α, β);
	}
}

template<>
void Generators<ushort>::makeGroupOutput(const CRepository<ushort>* pElemGroup, bool outToScreen, bool checkNestedGroups) {
	this->printTable(this->getObject(0), false, outToScreen, this->numObjects(), "");
	setOrbitsCreated(false);
}

template<>
void Generators<tchar>::makeGroupOutput(const CRepository<tchar>* pElemGroup, bool outToScreen, bool checkNestedGroups) {
	createOrbits(pElemGroup);
	this->printTable(this->getObject(0), false, outToScreen, this->numObjects(), "");

	if (checkNestedGroups) {
		const auto retVal = testNestedGroups((const CGroupInfo*)pElemGroup);
		reportNestedGroupCheckResult(retVal, outToScreen);
	}

	setOrbitsCreated(false);
}

const char* graphTypeStr(t_graphType grType) {
	switch (grType) {
	case t_regular:		return "merely regular";
	case t_triangular:	return "triangular";
	case t_rock:		return "rock";
	case t_complete:
	default:			return "complete";
	}
}