﻿#include "TopGun.h"
#if !USE_CUDA
void _printf(FILE* f, bool toScreen, const char* format, const char* pStr) {
	if (f)
		fprintf(f, format, pStr);

	if (toScreen)
		printf(format, pStr);
}

#if PrintImprovedResults
void alldata::outputResults(int iDay, const unsigned char* pResult, int cntr) const
{
	char buffer[256];
	const bool toScreen = PrintImprovedResults > 1;
	FOPEN_W(f, ImprovedResultFile, canonCalls(1) || cntr ? "a" : "w", m_file);

	const unsigned char* pDayPerm = NULL;
	auto flag = true;
	if (cntr) {
		flag = m_pCheckCanon->improvedResultIsReady(t_bResultFlags::t_readyToExplainMatr);
		if (flag) {
			pDayPerm = pResult + iDay * numPlayers();
			sprintf_s(buffer, "Improved Result #%d for %d days  m_groupIndex = %d:\n", cntr, iDay, m_groupIndex);
			_printf(f, toScreen, buffer);
		}

		if (m_pCheckCanon->improvedResultIsReady(t_bResultFlags::t_readyToExplainTxt))
			_printf(f, toScreen, "%s\n", m_pCheckCanon->comment());
	}
	else {
		sprintf_s(buffer, "Initial Result #%zd (%zd):\n", canonCalls(0), ((Table<char>*) m_pRes)->counter());
		_printf(f, toScreen, buffer);
	}

	if (flag)
		outMatrix(pResult, iDay, numPlayers(), m_groupSize, 0, f, false, toScreen, cntr, pDayPerm);

	FCLOSE_W(f, m_file);
}
#endif

#if CHECK_PERMUTATIONS
void alldata::outputError() const {
	extern char lastError[];
	FOPEN_W(f, ImprovedResultFile, "a", m_file);
	_printf(f, false, lastError);
	FCLOSE_W(f, m_file);
}
#endif

void alldata::reportCurrentMatrix()
{
	m_cTime = clock();
	m_rowTime[iDay] = m_cTime - m_iTime;
	if (maxDays < iDay || m_cTime - m_rTime > ReportInterval)
	{
	//	if (m_bPrint)
		{
			printf("Matrix index %d: Current data for %s-matrix %zd: rows=%d, build time=%d, time since start=%d\n",
				m_threadNumber, m_fHdr, nLoops + 1, iDay + 1, m_cTime - m_rTime, m_cTime - m_iTime);
			printResultWithHistory("Current matrix", iDay + 1);
		}
#if ReportCheckLinksData
		if (m_bPrint)
			reportCheckLinksData();
#endif
		StatReportPeriodically(ResetStat, "Stat current. iDay", iDay, bPrint);

		m_rTime = m_cTime;
		maxDays = iDay;
	}
}
#endif

void alldata::printPermutationMatrices(const int iMode) const {
	if (m_groupSize != 3 || iMode < 2)
		return;
	int maxStr = 144;
	auto v = getV0();
	int cyclesSize = m_maxCommonVSets * m_nGroups;
	tchar* cycles = new tchar[cyclesSize];
	int pm0Size = m_nGroups * m_nGroups * 2;
	tchar* pm0 = new tchar[pm0Size];
	int pmSize = pm0Size * m_maxCommonVSets;
	tchar* pm = new tchar[pmSize];
	for (int i = 1; i < iDay; i++) {
		for (int i0 = 0; i0 < i; i0++) {
			if (i0 == i)
				continue;
			if (iMode == 2 && i0 != 0)
				break;
			//if (iMode == 3 && i0 != 1 && i != 4)
			if (iMode == 3 && i0 != i - 1)
				continue;
			auto nv = getAllV(v, m_maxCommonVSets, i0, i);
			memset(pm0, 0, pm0Size);
			memset(pm, 0, pmSize);
			memset(cycles, unset, cyclesSize);
			for (int j = 0; j < nv; j++) {
				for (int k = 0; k < m_nGroups; k++) {
					int m = neighbors(i)[v[j * m_nGroups + k]];
					int n = result(i)[m];
					pm[j * m_nGroups + m / m_groupSize + k * nv * m_nGroups] = 1;
					pm0[m / m_groupSize + k * m_nGroups * 2] = n;
					pm0[m / m_groupSize + m_nGroups + k * m_nGroups * 2] = 1;
				}
				TrCycles trc;
				const auto ncycles = p3Cycles(&trc, neighbors(i0), neighbors(i), v + j * m_nGroups, result(i0), result(i), eCheckErrors);
				if (ncycles > 0)
					memcpy(cycles + j * m_nGroups, trc.length, ncycles);
			}
			printf("\nResult rows (%d,%d), cycles and corresponding Permutation matrices\n", i0, i);
			printTableColor("", result(i0), 1, m_numPlayers, m_groupSize);
			printTableColor("", result(i), 1, m_numPlayers, m_groupSize);
			printf("\n");
			printTableColor("", pm0, m_nGroups, m_nGroups * 2, m_nGroups);
			int istr = 0;
			int nvMax = 6;
			for (int inv = 0; inv < nv; inv += nvMax) {
				printf("\n");
				printTableColor("c", cycles + inv * m_nGroups, 1, m_nGroups * min((nv - inv), nvMax), m_nGroups);
				for (int k = 0; k < m_nGroups; k++) {
					printTableColor("", pm + (inv + k * nv) * m_nGroups, 1, m_nGroups * min((nv - inv), nvMax), m_nGroups);
				}
			}
		}
	}
	delete[] cycles;
	delete[] pm;
	delete[] pm0;
}
static tchar __colors[6] = { 32, 18, 5, 21, 26, 4 };
void printTableColor(char const* name, ctchar* c, int nl, int nc, int np, int ns, bool makeString, ctchar* co, int* t)
{
	int ind = 0;
	if (name && name[0]) {
		printf("%s:", name);
		if (t)
			printfGreen("     Last column: Row change time stamp (sec)\n");
		else if (nl > 1)
			printf("\n");
	}
	for (int j = 0; j < nl; j++, ind += nc)
	{
		if (makeString) printf("\"");
		const auto frmt = nc > 16 ? "%2d" : "%3d";
		for (int i = 0; i < nc; i++)
		{
			ctchar v = c[ind + i];
			if (np > 0 && (i % np) == 0 && i > 0)
				printf(" ");
			if (co) {
				if (v == co[ind + i])
					printf(frmt, v);
				else
					if (nc > 16)
						printfGreen("%2d", v);
					else
						printfGreen("%3d", v);
			}
			else if (v < 67 || (np > 1 && np < 7))
			{
				if (g_useColors) printf("\x1b[38;5;%dm%2d", 28 + ((np > 1 && np < 7) ? __colors[v % np] : v) * 3, v);
				else printf("%2d", v);
				if (g_useColors) printf("\x1b[0m");
			}
			else if (v == unset)
				printf(" .");
			else
				printf("%2d", v);
		}
		if (j + 1 >= nl || ns <= 0 || ((j + 1) % ns) == 0)
		{
			if (makeString)
				printf(" \"");
			if (t)
				printfGreen("//%7d", (t[j] >= 0 ? t[j] : -(1 + t[j])) / 1000);
			printf("\n");
		}
		else
			printf(" ");
	}
}

void alldata::printResultWithHistory(char const* name, int nRows)
{
	int offset = 0;
	for (int i = 0; i < nRows; i++, offset += m_numPlayers) {
		if (m_rowTime[i] >= 0) {
			memcpy(m_pResultsPrev + offset, m_pResultsPrev2 + offset, m_numPlayers);
			memcpy(m_pResultsPrev2 + offset, result() + offset, m_numPlayers);
			m_rowTime[i] = -(m_rowTime[i] + 1);
		}
	}
	printTableColor(name, result(), nRows, m_numPlayers, m_groupSize, 0, true, m_pResultsPrev, m_rowTime);

}

sLongLong TopGun::printThreadsStat(int nMatrices, int nProccesed, const clock_t& m_iTime, bool bPrintSetup, bool bPrintToScreen)
{
	const sLongLong* cntTotal = m_cntTotal;
	const sLongLong* cnt = m_cnt;
	sLongLong sum1 = 0, sum2 = 0;
	for (uint i = 0; i < numThreads; i++)
	{
		const auto j = i * 2;
		sLongLong d = cnt[j];
		if (d < 0)
			d = -1 - d;
		sum1 += cntTotal[j] + d;
		sum2 += cntTotal[j + 1] + cnt[j + 1];
	}

	const char* fhdr = getFileNameAttr(paramPtr());
	int time[4];
	const int multTime[] = { 60, 60, 24 };
	auto *pUnitTime = "smhd";
	time[0] = (int)((clock() - m_iTime) / 1000. + 0.5);
	for (int i = 0; i < countof(multTime); i++) {
		time[i + 1] = time[i] / multTime[i];
		time[i] %= multTime[i];
	}
	
	m_reportInfo = "";
	if (!param(t_timing_output_mode)) {
		char timeBuf[256], * pTime = timeBuf;
		for (int i = countof(time); i--;)
			if (time[i] || pTime != timeBuf || !i)
				SPRINTFD(pTime, timeBuf, "%2d%c", time[i], pUnitTime[i]);

		m_reportInfo = std::format("T = {}: ", timeBuf);
	}

	m_reportInfo += std::format(
		"{} (from {}) {}-matrices ({}x{}) processed by {} threads. {} {}-matrices ({}x{}) generated\n",
		nProccesed - param(t_nFirstIndexOfStartMatrices) + 1, nMatrices - param(t_nFirstIndexOfStartMatrices) + 1, 
		fhdr, numPlayers(), nRowsStart(), numThreads, sum1, fhdr, numPlayers(), nRowsOut());

	if (bPrintSetup && !param(t_timing_output_mode)) 
	{
		char buffer[1024], *pBuf = buffer;
		const auto lenBuf = sizeof(buffer);
		bool bAC = true;
		for (uint i = 0; i < numThreads; i++)
		{
			if ((i % 10) == 0)
				SPRINTFS(pBuf, buffer, lenBuf, "\n");

			const auto j = i * 2;
			sLongLong d = cnt[j];
			if (d < 0)
				d = -1 - d;
			auto cIdle = threadActive[i] ? "" : ".I";
			if (cntTotal[j] + d > 0) {
				SPRINTFS(pBuf, buffer, lenBuf, " %d[%zd].%d[%zd]%s", i + 1, cntTotal[j] + d, matrixIndex[i], d, cIdle);
				bAC = false;
			}
			else
				SPRINTFS(pBuf, buffer, lenBuf, " %d.%d%s", i + 1, matrixIndex[i], cIdle);
		}
		if (bAC)
			m_reportInfo += std::format("Data format below: 'Thread.Current_Index[.Idle]':{}\n", buffer);
		else
			m_reportInfo += std::format("Data format below: 'Thread[Results].Current_Index[Results][.Idle]':{}\n", buffer);
	}
	if (bPrintToScreen)
		printfYellow("%s", m_reportInfo.c_str());
	outputIntegratedResults(NULL, 3);
	return sum1;
}
void printTransformed(int nrows, int ncols, int groupSize, const tchar* tr, const tchar* ttr, const tchar* pImatr, const tchar* pTmatr, int numRow, sLongLong nLoops, int finalKMindex)
{
	if (nLoops)
		printf("Calculated Matrix %zd can be improved. See below (nKm=%d row=%d)\n", nLoops, finalKMindex, numRow);
	
	printTable("Tr source", tr, 1, ncols, groupSize);
	printTable("Tr actual", ttr, 1, ncols, groupSize);
	printTable("Original", pImatr, nrows, ncols, groupSize);
	printTable("Translated", pTmatr, nrows, ncols, groupSize);
}
std::string printWithPowers(const std::string& strInput) {
	auto str = strInput.c_str();

	// If colors/superscripts are disabled, just return the original string
	if (!g_useColors)
		return std::string(str);

	std::string result;

	while (*str) {
		if (*str == '^') {

			// Convert all consecutive digits to superscripts
			while (*++str && std::isdigit(static_cast<unsigned char>(*str))) {
				char digit = *str;

				switch (digit) {
				case '0': result += "\xE2\x81\xB0"; break; // ⁰
				case '1': result += "\xC2\xB9";     break; // ¹
				case '2': result += "\xC2\xB2";     break; // ²
				case '3': result += "\xC2\xB3";     break; // ³

				case '4': result += "\xE2\x81\xB4"; break; // ⁴
				case '5': result += "\xE2\x81\xB5"; break; // ⁵
				case '6': result += "\xE2\x81\xB6"; break; // ⁶
				case '7': result += "\xE2\x81\xB7"; break; // ⁷
				case '8': result += "\xE2\x81\xB8"; break; // ⁸
				case '9': result += "\xE2\x81\xB9"; break; // ⁹
				}
			}
		}
		else
			result += *str++;
	}

	return result;
}
std::string getPrimeFactorization(UInt n) {
	if (n == 0) return "0";
	if (n == 1) return "1";

	std::string result = "";
	bool first = true;

	// 1. Factor out the power of 2
	int count = 0;
	while (n % 2 == 0) {
		count++;
		n = n / 2;
	}
	if (count > 0) {
		result += "2";
		if (count > 1) result += "^" + std::to_string(count);
		first = false;
	}

	// 2. Factor out odd primes
	for (UInt i = 3; i * i <= n; i = i + 2) {
		count = 0;
		while (n % i == 0) {
			count++;
			n = n / i;
		}
		if (count > 0) {
			if (!first) result += "*";
			result += TO_STRING(i);
			if (count > 1) result += "^" + std::to_string(count);
			first = false;
		}
	}

	// 3. If n is still greater than 1, the remaining n is a prime itself
	if (n > 1) {
		if (!first) result += "*";
		result += TO_STRING(n);
	}

	return result;
}