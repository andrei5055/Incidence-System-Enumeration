#include <iostream>
#include "TableLS.h"
#include "TripleSys.h"
#include "k1212_4_20.h"
#include "k1111p1f.h"
#include "k16p1f.h"
#include "k16A2.h"
#include "k16a2Old.h"
#include "k18a2.h"
#include "k18a2Old.h"
#include "k20a2.h"
#include "k14a2.h"
#include "KSolveGen.h"
#include "kOrbits.h"

#if !USE_CUDA && USE_BINARY_CANONIZER
#include "k-SysSupport.h"
#include "CDTools.h"
#endif
#include <filesystem>

using namespace std;

#if CHECK_GET_ROW
TableAut* pReslt = NULL;
#endif
bool alldata::checkAndSave(ctchar* data, int mode) {
	memcpy(result(0), data, m_numDaysResult * m_numPlayers);
	//printTable("Result", result(), m_numDaysResult, m_numPlayers, m_groupSize);
	m_lastRowWithTestedTrs = 0;
	iDay = m_numDaysResult;
	for (int i = 0; i < iDay; i++)
		u1fSetTableRow(neighbors(i), result(i));

	setArraysForLastRow(iDay);

	if (!linksFromMatrix(links(), result(), iDay, false)) {
		printTable("*** Internal error: 1", result(), m_numDaysResult, m_numPlayers, m_groupSize);
		myExit(1);
	}
	if (mode != 2) {
		if (!cnvCheckNew(0, iDay)) {
			//if (m_bPrint) 
			//	printfYellow("*** Calculated result is not canonical (not recorded, skipped)\n");
			return false;
		}
	}
	if (mode == 1)
		return true;
	nLoops++;
	m_finalKMindex++;
	TableAut* pResult = (TableAut*) m_pRes;
	if (pResult) {
		char stat[1024];
		getAllCycles(neighbors(), iDay);
		matrixDB()->addObjDescriptor(orderOfGroup(), matrixStatOutput(stat, sizeof(stat), m_TrCyclesAll));
		pResult->setInfo(stat); 
		pResult->setGroupOrder(orderOfGroup());
		if (param(t_savingMatricesToDisk)) {
			pResult->printTable(result(), true, false, numDaysResult());
		}
		if (m_bPrint) {
			//printf("%d(%zd): " AUT "%d, % s\n", m_threadNumber, nLoops, orderOfGroup(), stat);
			// print on screen result with highlighted differences from prev result
			//printResultWithHistory("", iDay);
			if (m_printMatrices & 2)
				printPermutationMatrices(2);
		}
		/**
		if (orderOfGroup() > 1) {
			for (int i = 0; i < countof(pAutGroup); i++) {
				if (pAutGroup[i])
					pAutGroup[i]->makeGroupOutput(this, m_bPrint);
			}
		}
		*/
	}
	return true;
}
bool KGenSaveResult(void* pAppData, ctchar* result, int r4, int r5, int mode) {
	return ((alldata*)pAppData)->checkAndSave(result, mode);
}
CC sLongLong alldata::Run(int threadNumber, eThreadStartMode iCalcMode, CStorageSet<tchar>* secondRowsDB,
	ctchar* mStart0, ctchar* mfirst, int nrowsStart, sLongLong* pcnt, string* pOutResult, int iThread) {
	// Input parameters:
	const auto iCalcModeOrg = iCalcMode;
	iPlayer = 0;
	m_useZStabilizer = 0; // must be above any call to canonizer (cnvCheckNew())
	m_v4Row[0] = param(t_v4Row); m_v4Row[1] = param(t_v4RowB); m_v4Row[2] = param(t_v4RowC); m_v4Row[3] = param(t_v4RowD);
	if (m_v4Row[0] || m_v4Row[1] || m_v4Row[2] || m_v4Row[3]) {
		m_bAdjustRow4 = true;
		m_v4[0] = param(t_v4); m_v4[1] = param(t_v4B); m_v4[2] = param(t_v4C); m_v4[3] = param(t_v4D);
	}
#if !USE_CUDA
	m_printMatrices = (iThread == 0 || param(t_numThreads) < 2) ? param(t_printMatrices) : 0;
	m_bPrint = (m_printMatrices & 1) != 0;
	bool bPrintPeriodic = (m_printMatrices & 32) != 0;
	m_bPrintAll = m_bPrint || bPrintPeriodic;
	m_fHdr = getFileNameAttr(sysParam());
	m_cTime = m_rTime = m_iTime = m_pTime = clock();
#endif
	bool bSaveMatrix = false;
	const bool bNotSpecialMode = iCalcModeOrg != eCalcSecondRow && iCalcModeOrg != eCalculateRows;
	const auto bSavingMatricesToDisk = bNotSpecialMode ? param(t_savingMatricesToDisk) : false;

	int minRows = nrowsStart;
	m_doNotExitEarlyIfNotCanonical = (m_test & 2) != 0; // || param(t_generateMatrixExample) != 0;
	memset(m_rowTime, 0, m_numDaysResult * sizeof(m_rowTime[0]));
	m_allRowPairsSameCycles = param(t_any2RowsConvertToFirst2) != 0 || param(t_allowUndefinedCycles) == 0;
	m_lastRowWithTestedTrs = 0;
	m_threadNumber = threadNumber;
	const auto p1f_counter = param(t_p1f_counter);
	void* pIS_Canonizer = NULL;
#if !USE_CUDA && USE_BINARY_CANONIZER
	if (m_ppBinMatrStorage)
		pIS_Canonizer = createCanonizer(numPlayers(), m_groupSize);
#endif
	//if (iThread == 0 && iCalcMode == eCalculateMatrices)
	//return 0;
	m_pSecondRowsDB = secondRowsDB;
	if (iCalcMode == eCalcSecondRow) {
		iCalcMode = eCalcResult;
		m_createSecondRow = 1;
		m_numDaysResult = 2;
		nrowsStart = 0;
	} 
	else
		m_createSecondRow = 0;
	const bool bCBMP = !completeGraph();
	const auto groupSize_2 = m_groupSize == 2;

	if (iDay == 0)
		iDay = nrowsStart;
	if (iDay > numDaysResult()) // && !(m_printMatrices & 16) && !(m_test & 1))
		iDay = numDaysResult(); // warning?

	if (mStart0)
	{
		memcpy(result(), mStart0, nrowsStart * m_numPlayers);
		if (m_printMatrices & 64)
			printTable("Input matrix", result(), iDay, m_numPlayers, m_groupSize, 0, true);
		linksFromMatrix(links(), result(), nrowsStart);
	}

	for (int i = 0; i < iDay; i++)
		u1fSetTableRow(neighbors(i), result(i));

	initPrecalculationData(iCalcModeOrg, nrowsStart);

	int maxPlayerInFirstGroup = groupSize_2 ? m_secondPlayerInRow4Last : m_numPlayers;
#if !USE_CUDA
	const auto semiSymGraph = !m_createSecondRow && numDaysResult() > 2 && param(t_semiSymmetricGraphs) == 1;
	const auto outAutGroup = param(t_outAutomorphismGroup);
	IOutGroupHandle<tchar>* pAutGroup[4] = { NULL };
	if (semiSymGraph || outAutGroup) {
		if (bSavingMatricesToDisk) {
			if (outAutGroup & 1)
				pAutGroup[0] = new Generators<tchar>(outAutGroup, "\nOrbits and generators of the Aut(M) acting on elements", m_numPlayers);

			if (outAutGroup & 2)
				pAutGroup[1] = new COutGroupHandle<tchar>(outAutGroup, "\nAut(M) acting on elements", m_numPlayers);
		}

		if (semiSymGraph || bSavingMatricesToDisk && (outAutGroup & 12))
			pAutGroup[2] = new RowGenerators<tchar>(outAutGroup, numDaysResult());

		if (semiSymGraph || bSavingMatricesToDisk && (outAutGroup & 48))
			pAutGroup[3] = new CKOrbits(outAutGroup, m_numPlayers, m_groupSize, numDaysResult());
	}

	sLongLong nMCreated = 0;
	auto mTime = clock();
	unsigned char* bResults = NULL;

	
	TableAut* pResult = NULL;
	IDatabase* pLS_DB = NULL;
	const auto iSaveLS = m_groupSize <= 3 && param(t_saveLatinSquareType);
	if (iSaveLS) {
		pResult = new TableLS(MATR_ATTR, m_numDays, m_numPlayers, 0, m_groupSize, true, true, iSaveLS, bCBMP);
		pLS_DB = addDB(db_LS);
	}
	else
		pResult = new TableAut(MATR_ATTR, m_numDays, m_numPlayers, 0, m_groupSize, true, true);

	auto* pResultLS = static_cast<TableLS*>(pResult);
#if CHECK_GET_ROW
	pReslt = pResult;
#endif
	if (m_bAdjustRow4 && iDay > 0) {
		for (int i = 0; i < 4; i++) {
			if (m_v4Row[i]) {
				if (links(1)[m_v4[i]] != unset) {
					char rowInd = i == 0 ? ' ' : 'A' + (char)i;
					printfRed("V4 Filter: Group (1,%d) requested by v4%c=%d to be in v4Row%c=%d, but already used in start matrix rows\n", 
						m_v4[i], rowInd, m_v4[i], rowInd, m_v4Row[i]);
					//ASSERT_IF(1);
					//myExit(110);
					goto noResult;
				}
			}
		}
	}
	if (bSavingMatricesToDisk) {
		string fName = format("{:0>10}.txt", threadNumber);
		if (m_improveResult) {
			const auto lenResult = (m_numDays + 1) * (m_numPlayers + m_numDays);
			bResults = new unsigned char[(m_improveResult > 1 ? 2 : 1) * lenResult];
			createFolderAndFileName(ImprovedResultFile, sysParam(), t_ImprovedResultFolder, numDaysResult(), fName);
		}

		createFolderAndFileName(ResultFile, sysParam(), t_ResultFolder, numDaysResult(), fName);

		pResult->allocateBuffer(32);
		const auto pResFile = ResultFile.c_str();
		if (param(t_keepPrevResult) && std::filesystem::exists(pResFile)) {
			printfRed("*** Error: Request to override existing file rejected (KeepPrevResult=%d, file name=%s)\n", 
				param(t_keepPrevResult), pResFile);
			myExit(1);
		}
		pResult->setOutFileName(pResFile, true);
		m_pRes = pResult;

		if (outAutGroup) {
			for (int i = 0; i < countof(pAutGroup); i++) {
				if (pAutGroup[i])
					pAutGroup[i]->setOutFileName(pResFile);
			}
		}
	}
#endif
	CUDA_PRINTF("*** mStart0 = %p\n", mStart0);
#if !USE_CUDA
	if (param(t_generateMatrixExample)) {
		if (m_numPlayers >= 4 && param(t_CBMP_Graph) < 2 && m_groupSize == 2 && !m_createSecondRow) {
			iDay = m_numDaysResult;
			for (int i = 0; i < m_numPlayers; i++)
				result(0)[i] = i;
			if (m_pSecondRowsDB && m_pSecondRowsDB->numObjects() > 0) {
				memcpy(result(1), m_pSecondRowsDB->getObject(0), m_numPlayers);
			}
			else {
				memset(result(1), 0, m_numPlayers);
			}
			generateKn(result(0), m_numPlayers, m_numDaysResult);
			//printTable("input matrix", result(0), m_numDaysResult, m_numPlayers, m_groupSize);
			if (!canonizeMatrix(iDay)) {
				printfYellow("*** Can't canonize generated matrix\n");
			}
		}
		else if (param(t_CBMP_Graph) > 1) {
			iDay = m_numDaysResult;
			nrowsStart = m_numDaysResult;
			if (!generateMatrixExample())
				goto noResult;
			if (m_createSecondRow) {
				memcpy(m_pSecondRowsDB->getNextObject(), result(1), m_numPlayers);
				m_finalKMindex = 1;
				nLoops = 1;
				goto noResult;
			}
		}
	}
	else if (sysParam()->strVal[t_InputDataFileName]->length() && !m_createSecondRow) {

		tchar tr[MAX_PLAYER_NUMBER];
		memset(tr, 0, m_numPlayers);
		for (int i = 0; i < m_numPlayers; i++)
			tr[result(0)[i]] = i;
		kmTranslate(result(0), result(0), tr, m_numDays * m_numPlayers);
		if (!canonizeMatrix(m_numDays))
			goto noResult;
		if (!linksFromMatrix(links(), result(), m_numDays, false)) {
			printfRed("*** Internal error\n");
			goto noResult;
		}
	}
#endif
	p1fCheckStartMatrix(iDay);
	m_playerIndex = 0;
	if (param(t_CanonizeInput) && iDay > 2) {
		if (!canonizeMatrix(iDay))
			goto noResult;
		if (!linksFromMatrix(links(), result(), iDay, false)) {
			printfRed("*** Internal error: Canonize input, set links\n");
			goto noResult;
		}
	}
#if !USE_CUDA
#if 1   // Matrix from data.h
	if ((m_test & 1) && (iCalcModeOrg != eCalcSecondRow)){
		if (!iDay) {
			printfRed("*** Error: parameter Test=%d, but matrix not defined in data.h\n", m_test);
			myExit(1);
		}
		printfGreen(" SW uses input matrix from data.h (Test=%d)\n", m_test);
		canonizeMatrix(iDay);
#if 0
		minRows = iDay--;
		goto checkCurrentMatrix;
		//exit(0);
#endif
	}
#endif
#endif
#if 0
	const auto checkFlag = iDay == m_numDays || iDay == numDaysResult();
	if (checkFlag)
	{
		const auto retVal = improveMatrix(m_improveResult, NULL, 0/*, bResults, lenResult()*/);
#if 0
		if (retVal) {
			goto noResult;
		} 
#endif
		int ir = checkCurrentResult(m_bPrint);
		//if (improveMatrix(m_improveResult, NULL, 0/*, bResults, lenResult()*/))
		//	return -1;
		// special case if input is full result matrix or UseTwoLastDaysG2 mode
		switch (ir) {
		case -1:
		case  1: goto noResult;
		default: break;
		}
	}
#endif

	bPrevResult = false;
	
	if (iDay > 0 && param(t_useKSolve)) {
		if (m_groupSize == 2 && m_numDays == m_numDaysResult && m_nPrecalcRows == 3 &&
			param(t_allowUndefinedCycles) == 0 && param(t_any2RowsConvertToFirst2) == 1 && param(t_CBMP_Graph) <= 2 &&
			param(t_MultiThreading) == 1 && iDay == 3 && m_precalcMode == eCalculateRows) {
			if (m_pKSolver) {
				printfRed("*** Internal error, K-Solve already in use, exit\n");
				myExit(1);
			}
			int kThreads = param(t_numKThreads);
			kThreads = kThreads / param(t_numThreads);
			if (kThreads < 1)
				kThreads = 1;
			if (m_bPrint)
				printf("Number of threads per K-Solve process (KThreads): %d\n", kThreads);

			bool bCBMP = !completeGraph();

			if (param(t_useKSolve) & (32 + 64)) {
				if (m_numPlayers == 16 && !bCBMP &&
					sysParam()->u1fCycles[0] && sysParam()->u1fCycles[0][0] == 1 &&
					sysParam()->u1fCycles[0][1] == 16)
				{
					const FactorParams factParam = { K16_N, K16_MATCH, K16_FIXED, K16_M_MAX };

					if (param(t_useKSolve) & 64)
						m_pKSolver = new K16A2Old(factParam, m_threadNumber, kThreads, result(0), KGenSaveResult, (void*)this, m_bPrint);
					else {
						m_pKSolver = new K16A2(factParam, m_threadNumber, kThreads, result(0), KGenSaveResult, (void*)this, m_bPrint);
						m_precalcMode = eCalculateMatrices; // need to be before solve to check results for canonicity (but after cnvCheckNew())

						m_pKSolver->solve(1);

						goto noResult;

					}
				}
				else if (m_numPlayers == 18 && !bCBMP &&
					sysParam()->u1fCycles[0] && sysParam()->u1fCycles[0][0] == 1 &&
					sysParam()->u1fCycles[0][1] == 18)
				{
					const FactorParams factParam = { K18A2::NP, K18A2::NM, K18A2::NFIXED, K18A2::M_MAX, m_numDaysResult };

					if (param(t_useKSolve) & 64) {
						// Starter pool + arc-consistency + orbit-clique (L=4 order-4 autos).
						// Fed via addRow(); solve(0) is invoked later by endOfRowPrecalculation.
						m_pKSolver = new K18A2Old(factParam, m_threadNumber, kThreads, result(0), KGenSaveResult, (void*)this, m_bPrint);
					}
					else {
						m_pKSolver = new K18A2(factParam, m_threadNumber, kThreads, result(0), KGenSaveResult, (void*)this, m_bPrint);

						m_precalcMode = eCalculateMatrices; // need to be before solve to check results for canonicity (but after cnvCheckNew())

						m_pKSolver->solve(1);

						goto noResult;
					}
				}
				else if (m_numPlayers == 20 && !bCBMP &&
					sysParam()->u1fCycles[0] && sysParam()->u1fCycles[0][0] == 1 &&
					sysParam()->u1fCycles[0][1] == 20)
				{
					// K20: no cyclic engine -- the unseeded representative method is the only
					// solver path (UseKSolve & 32). Constructs the minimal host and runs once.
					const FactorParams factParam = { K20A2::NP, K20A2::NM, K20A2::NFIXED, K20A2::M_MAX, m_numDaysResult };

					m_pKSolver = new K20A2(factParam, m_threadNumber, kThreads, result(0), KGenSaveResult, (void*)this, m_bPrint);

					m_precalcMode = eCalculateMatrices; // before solve to check results for canonicity

					m_pKSolver->solve(1);

					goto noResult;
				}
				else if (m_numPlayers == 14 && !bCBMP &&
					sysParam()->u1fCycles[0] && sysParam()->u1fCycles[0][0] == 1 &&
					sysParam()->u1fCycles[0][1] == 14)
				{
					// K14: validation oracle (known P1F counts), rep method only. Same minimal-host
					// path as K20 (UseKSolve & 32); constructs the host and runs once.
					const FactorParams factParam = { K14A2::NP, K14A2::NM, K14A2::NFIXED, K14A2::M_MAX, m_numDaysResult };

					m_pKSolver = new K14A2(factParam, m_threadNumber, kThreads, result(0), KGenSaveResult, (void*)this, m_bPrint);

					m_precalcMode = eCalculateMatrices; // before solve to check results for canonicity

					m_pKSolver->solve(1);

					goto noResult;
				}
			}
			else if (param(t_useKSolve) & 1) {
				if (m_numPlayers == 16 && !bCBMP &&
					sysParam()->u1fCycles[0] && sysParam()->u1fCycles[0][0] == 1 &&
					sysParam()->u1fCycles[0][1] == 16)
				{
					const FactorParams factParam = { K16_N, K16_MATCH, K16_FIXED, K16_M_MAX };
					m_pKSolver = new K16P1F(factParam, m_threadNumber, kThreads, result(0), KGenSaveResult, this, m_bPrint);
				}

				else if (m_numPlayers == 22 && bCBMP &&
					sysParam()->u1fCycles[0] && sysParam()->u1fCycles[0][0] == 1 &&
					sysParam()->u1fCycles[0][1] == 22)
				{
					const FactorParams factParam = { K1111_N, K1111_MATCH, K1111_FIXED, K1111_M_MAX };
					m_pKSolver = new K1111P1F(factParam, m_threadNumber, kThreads, result(0), KGenSaveResult, this, m_bPrint);
				}

				if (m_numPlayers == 24 && bCBMP &&
					sysParam()->u1fCycles[0] && sysParam()->u1fCycles[0][0] == 1 &&
					sysParam()->u1fCycles[0][1] == 4 && sysParam()->u1fCycles[0][2] == 20)
				{
					const FactorParams factParam = { K1212_N, K1212_MATCH, K1212_FIXED, K1111_M_MAX };
					m_pKSolver = new K1212_4_20(factParam, m_threadNumber, kThreads, result(0), KGenSaveResult, this, m_bPrint);
				}
			}
			// Fallback to KSolveGen (Bit 1)
			if (!m_pKSolver && (param(t_useKSolve) & 2)) {
				tchar cycle[2] = { 0 }, * p = cycle;
				int k = 1;
				cycle[0] = m_numPlayers;
				if (sysParam()->u1fCycles[0] && sysParam()->u1fCycles[0][0] == 1)
					p = (tchar*)sysParam()->u1fCycles[0] + 1;
				for (k = 0; k < MAX_CYCLES_PER_SET; k++)
					if (p[k] == 0)
						break;

				const FactorParams factParam = { m_numPlayers, bCBMP ? m_numPlayers / 2 : m_numPlayers - 1, 3, KGEN_M_MAX };
				m_pKSolver = new KSolveGen(factParam, bCBMP, p, k, m_threadNumber, kThreads, result(0),
					KGenSaveResult, this, m_bPrint, m_v4Row, m_v4);
				m_pKSolver->preSolve();
				m_lastRowWithTestedTrs = 0;
				iDay = m_nPrecalcRows;
				m_precalcMode = eCalculateRows; // needed for cnvCheckNew
				if (!cnvCheckNew(0, m_nPrecalcRows, false)) {
					printfRed("*** Internal error, fixed rows are not canonical\n");
					printTable("", result(), m_nPrecalcRows, m_numPlayers, m_groupSize);
					exit(1);
				}
				iDay = m_nPrecalcRows + 1;
				if (m_bPrint)
					printf("Candidates filtered by canonicity (slot/before/after):");
				m_secondPlayerInRow4First = 1 + m_nPrecalcRows * (completeGraph() ? 1 : 2);
				for (int i = 0; i < m_numDaysResult - m_nPrecalcRows; i++) {
					int nRows = m_pKSolver->getCandidateCount(i);
					int nRowsAfter = 0;
					m_secondPlayerInRow4 = 1 + (m_nPrecalcRows + i) * (completeGraph() ? 1 : 2);
					for (int j = 0; j < nRows; j++) {
						if (!m_pKSolver->getCandidate(i, j, result(m_nPrecalcRows))) {
							printfRed("*** Internal error, i=%d, j=%d\n", i, j); exit(1);
						}
						m_lastRowWithTestedTrs = m_nPrecalcRows - 1;
						u1fSetTableRow(neighbors(m_nPrecalcRows), result(m_nPrecalcRows));
						if (!cnvCheckNew(0, m_nPrecalcRows + 1, true))
							m_pKSolver->deleteCandidate(i, j);
						else
							nRowsAfter++;
					}
					if (m_bPrint)
						printf(" %d/%d/%d", i, nRows, nRowsAfter);
				}
				m_precalcMode = eCalculateMatrices; // need to be before solve to check results for canonicity (but after cnvCheckNew())
				if (m_bPrint)
					printf("\n");
				m_pKSolver->solve(1);
				goto noResult;
			}
		}
		if (!m_pKSolver) {
			printfRed("*** Internal error, UseKSolve(%d) requested, but no compatible K-Solve exists, exit\n", param(t_useKSolve));
			myExit(1);
		}
	}
#if 1 && !USE_CUDA
	if (testGroupOrderEachSubmatrix(m_printMatrices, iCalcModeOrg)) {
		goto noResult;
	}
#endif
	if (iCalcMode == eCalculateMatrices)
		m_pRowUsage->init(iThread, param(t_numThreads));
	else if (iDay > 0) {
		if (m_precalcMode == eCalculateRows)
			m_pRowStorage->initPlayerMask(mfirst, maxPlayerInFirstGroup);
	 	setArraysForLastRow(iDay);
		//printTable("p1f", neighbors(), iDay, m_numPlayers, m_groupSize);
		m_useZStabilizer = param(t_useZStabilizer) && !m_doNotExitEarlyIfNotCanonical && bNotSpecialMode &&
			param(t_MultiThreading) == 1 && iDay == 3 && m_groupSize == 2 && m_nPrecalcRows == 0 ? 1 : 0;

		if (m_useZStabilizer) {
			m_ZStabilizer = new ZStabilizer();
			m_ZStabilizer->init(m_numPlayers, param(t_submatrixGroupOrderMin), bCBMP, m_bPrint);
			m_lastRowWithTestedTrs = 0;
			cnvCheckNew(0, iDay - 1);
			m_ZStabilizer->goDown();
			cnvCheckNew(0, iDay);
			m_useZStabilizer = 2;
		}
		minRows = iDay--;
		goto checkCurrentMatrix;
	}

	while (nLoops < LoopsMax)
	{
#if !USE_CUDA
		mTime = clock();
#endif
		CUDA_PRINTF(" *** nLoops = %lld\n", nLoops);
		while (iDay < numDaysResult() || bPrevResult)
		{
			if (m_nPrecalcRows && m_precalcMode == eCalculateMatrices) {
			ProcessPrecalculatedRow:
				const auto iRet = precalculatedSolutions(iCalcMode);
				switch (iRet) {
				case eCheckCurrentMatrix: goto checkCurrentMatrix;
				case eContinue: continue;
				case eNoResult: goto noResult;
				}
			}
			else {
				CUDA_PRINTF("   *** iDay = %d  bPrevResult = %d\n", iDay, bPrevResult);
				if (iDay < 0)
				{
					goto noResult;
				}
				if (bPrevResult)
				{
					if (iDay <= minRows || iDay < 2)
						goto noResult;
					if (!initPrevDay())
						continue;
				}
				else if (!initCurrentDay())
					continue;
			}
		ProcessOneDay:
			if (m_lastRowWithTestedTrs >= iDay)
				m_lastRowWithTestedTrs = iDay - 1;
			if (iDay < minRows)
				goto noResult;
			// temporary check that link table is ok
#if 0 //!USE_CUDA
			if (!iPlayer && iDay) {
				tchar* l = links(0);
				for (int i = 0;i < m_numPlayers * m_numPlayers; i++) {
					if (l[i] == iDay) {
						printfRed("Bad link(%d) at %d,%d\n", l[i], i / m_numPlayers, i % m_numPlayers);
						//exit(1);
					}
				}
			}
#endif
			if (!processOneDay()) {
				if (m_nPrecalcRows && m_precalcMode == eCalculateRows && m_secondPlayerInRow4) {
					if (m_bPrint)
						printf("%9d solutions for row starting with (0 %2d ...\n", m_nRows4Day, m_secondPlayerInRow4);
					if (!m_nRows4Day && m_groupSize == 2 && param(t_MultiThreading))
						goto noResult;
					const auto iRet = endOfRowPrecalculation(iCalcMode);
					switch (iRet) {
					case eCheckCurrentMatrix: goto checkCurrentMatrix;
					case eContinue: continue;
					case eNoResult: goto noResult;
					case eOk: break;
					}
				}
				bPrevResult = true;
				continue;
			}
			if (m_precalcMode == eCalculateMatrices) {
				ASSERT_IF(1); // error in SW
				goto noResult;
			}
			memcpy(result(iDay), tmpPlayers, m_numPlayers);

			if (!m_secondPlayerInRow4First && m_nPrecalcRows && m_precalcMode == eCalculateRows) {
				if (m_nPrecalcRows - 1 == iDay) {
					m_pRowStorage->initPlayerMask(NULL, maxPlayerInFirstGroup);
				}
				else if (m_nPrecalcRows == iDay) {
					m_secondPlayerInRow4 = m_secondPlayerInRow4First = result(m_nPrecalcRows)[1];
					m_lastRowWithTestedTrs = 0;
				}
			}

		checkCurrentMatrix:

			if (m_lastRowWithTestedTrs >= iDay)
				m_lastRowWithTestedTrs = iDay - 1;

#if !USE_CUDA
			if (bPrintPeriodic)
				reportCurrentMatrix();
#endif
			iDay++;
#if 0
			Stat("<10", 1, iDay < 10);
			Stat("=10", 2, iDay == 10);
			Stat("=11", 3, iDay == 11);
			Stat("=12", 4, iDay == 12);
			Stat(">12", 5, iDay > 12);
#endif
#if !USE_CUDA
			if (m_bPrintAll && (int)((++nMCreated) % 10000000) == 0)
				printf(" %zdM calls to checkCurrentResult\n", nMCreated / 1000000);
#endif

#if 1
			switch (checkCurrentResult(m_printMatrices, pIS_Canonizer)) {
			case -1:
				if (!m_createSecondRow && param(t_generateMatrixExample)) {
					printfYellow("\n*** GenerateMatrixExample=%d: generated matrix below processed but it is not canonical", param(t_generateMatrixExample));
					break;
				}
				goBack();
				if (m_nPrecalcRows && m_precalcMode == eCalculateMatrices)
					goto ProcessPrecalculatedRow;
				goto ProcessOneDay;
			case 1: goto noResult;
			default: break;
			}
#endif
			if (m_nPrecalcRows && m_precalcMode == eCalculateRows) {
				if (iDay == m_nPrecalcRows + 1) {
					addPrecalculatedRow();
					bPrevResult = true;
					continue;
				}
			}
		}
		ASSERT_IF(iDay < numDaysResult());

#if !USE_CUDA
		auto flag = true;
		const auto minGroupSize = semiSymGraph ? m_numDaysResult * m_numPlayers / 2 : 0;
		if (semiSymGraph && (flag = orderOfGroup() >= minGroupSize)) {
			int i = 2;
			for (; i <= 3; i++) {
				auto* pGroup = static_cast<RowGenerators<tchar>*>(pAutGroup[i]);
				pGroup->createGroupAndOrbits(this);
				const auto *pObj = pGroup->getObject(0);
				int j = pGroup->lenObject();
				while (j-- && !pObj[j]);
				if (j >= 0)
					break;
			}

			flag = i > 3;
		}
#else
		bool flag = true;
#endif

		if (flag && (m_createSecondRow || orderOfGroup() >= param(t_resultGroupOrderMin))) {
#if !USE_CUDA && USE_BINARY_CANONIZER && 0
			if (pIS_Canonizer) {
				const auto* pCanonBinaryMatr = runCanonizer(pIS_Canonizer, result(0), m_groupSize, iDay);
				if (m_ppBinMatrStorage[iDay]->updateRepo(pCanonBinaryMatr) < 0) {
					// The binary matrix has already been encountered
					printfRed("Error in canonizator\n");
					myExit(1);
				}
			}
#endif
			nLoops++;
			m_finalKMindex++;
#if !USE_CUDA
			if (m_createSecondRow) {
				memcpy(m_pSecondRowsDB->getNextObject(), result(1), m_numPlayers);
				if (m_bPrintAll) {
					const auto nr = secondRowsDB->numObjects();
					if (nr) {
						printf("Second row %04d:", nr);
						printTableColor("", secondRowsDB->getObject(nr - 1), 1, m_numPlayers, m_groupSize);
					}
				}
				if (groupSize_2 && sysParam()->u1fCycles[0] && sysParam()->u1fCycles[0][0] <= secondRowsDB->numObjects())
					goto noResult;
				goto cont1;
			}

			if (m_bPrint)
			{
				m_rTime = m_cTime = clock();
				setConsoleOutputMode();
				//report result
#if !DEBUG_NextPermut
				printf("\n%d(%zd): %s-Matrix (%d,%d), build time=%d, time since start=%d\n", 
					threadNumber, nLoops, m_fHdr, m_numPlayers, numDaysResult(), m_cTime - mTime, m_cTime - m_iTime);
#else
				extern int matr_cntr;
				printf("\n%5zd: %s-Matrix, matr_cntr = %d\n", nLoops, m_fHdr, matr_cntr);
#endif
			}

			char stat[1024];
			getAllCycles(neighbors(), iDay);
	
			matrixDB()->addObjDescriptor(orderOfGroup(), matrixStatOutput(stat, sizeof(stat), m_TrCyclesAll));
			if (pLS_DB) {
				pResultLS->constructLS(result(), numDaysResult());
				const LS_Type lsType = { pResultLS->isAtomicLS(), pResultLS->isSymmetricLS() };
				pLS_DB->addObjDescriptor(orderOfGroup(), (const char*)&lsType);
			}

			pResult->setInfo(stat);
			pResult->setGroupOrder(orderOfGroup());

			bSaveMatrix = bSavingMatricesToDisk && (!pLS_DB || pResultLS->isAtomicLS() || pResultLS->isSymmetricLS());
			if (m_bPrint || bSaveMatrix) {
#if 0			// record result and print on screen (if m_bPrint==true)
				pResult->printTable(result(), true, m_bPrint, numDaysResult());
#else			// record result without print on screen
				if (bSaveMatrix) {
					pResult->printTable(result(), true, false, numDaysResult());
					if (pResult->isLSCreated()) {
						m_nLS++;
						if (pResultLS->isAtomicLS())
							m_atomicLS++;
						if (pResultLS->isSymmetricLS())
							m_symmetricLS++;
						if (m_bPrint)
							printfYellow("Latin Square (%sAtomic, %sTotally symmetric) saved with the matrix below\n",
								pResultLS->isAtomicLS() ? "" : "Not ", pResultLS->isSymmetricLS() ? "" : "Not ");
					}
				}

				if (m_bPrint) {
					printf("%d(%zd): " AUT "%d, % s\n", threadNumber, nLoops, orderOfGroup(), stat);
					// print on screen result with highlighted differences from prev result
					printResultWithHistory("", iDay);
					if (m_printMatrices & 2)
						printPermutationMatrices(2);
					//printTable("links", links(), m_numPlayers, m_numPlayers, 0);
				}

				if (orderOfGroup() > 1) {
					for (int i = 0; i < countof(pAutGroup); i++) {
						if (pAutGroup[i])
							pAutGroup[i]->makeGroupOutput(this, m_bPrint);
					}
				}
#endif
				//cnvCheckNew(2, iDay);
			}

			//checkCommonValues();

			//Result.printTable(neighbors(), true, ResultFile, m_bPrint, numDaysResult());
			//reportCheckLinksData();
			//printTable("p1f", neighbors(), iDay, m_numPlayers, 2);
cont1:
			StatReportAfterEachResult(ResetStat, "Stat for matrix result. iDay", iDay, m_bPrint); // see stat.h to activate
			if (pcnt) {
				*pcnt = -m_finalKMindex - 1;
				*(pcnt + 1) = nLoops;
			}
			//printTable("Result", result(), iDay, m_numPlayers, m_groupSize, -1); // print comma separated values

			const auto pMatrTest = sysParam()->strVal[t_matrTest];
			if (pMatrTest) {
				auto testDescr = string(*pMatrTest);
				string testParam;
				const auto pos = testDescr.find(':');
				if (pos != string::npos) {
					testParam = testDescr.substr(pos + 1);
					testDescr = testDescr.substr(0, pos);
				}

				if (testDescr == "FindIsomorphicBaseElements") {
					FindIsomorphicBaseElements(testParam);
				}
				else {
					printfRed("Test \"%s\" is not implemented\n", testDescr.c_str());
					//myExit(1);
				}
			}
#endif
		}
		// 60 sec
#define LOOP_LENGTH	0//100 //10000
#if LOOP_LENGTH
		for (int i = 0; i < LOOP_LENGTH; i++)
			cnvCheckNew(0, iDay);
		goto noResult;
#endif
		if (iDay <= minRows)
			break;
		bPrevResult = true;
	}

noResult:

#if !USE_CUDA
#if USE_BINARY_CANONIZER
	releaseCanonizer(pIS_Canonizer);
#endif

	if (m_bPrint && param(t_saveLatinSquareType) && m_nLS)
		printfYellow("Matrix index %d: Latin Squares=%d, Atomic=%d, Totally symmetric=%d\n", threadNumber, m_nLS, m_atomicLS, m_symmetricLS);

	if (pcnt)
	{
		*pcnt = m_finalKMindex;
		*(pcnt + 1) = nLoops;
	}
	else {
		if (param(t_MultiThreading) <= 1) {
			std::string str;
			if (m_createSecondRow) {
				if (!param(t_timing_output_mode))  // AI - ??? Do we really need this information?
					str = format("{} row(s) calculated for '2nd rows DB' for matrices ({},{},{}), Execution time = {} ms\n",
						m_finalKMindex, m_numPlayers, numDaysResult(), groupSize(), clock() - m_iTime);
			}
			else {
				str = format("\nThread {}: {} non-isomorphic matrices ({},{},{}) created\n",
					threadNumber, m_finalKMindex, m_numPlayers, numDaysResult(), m_groupSize);
				
				if (param(t_saveLatinSquareType))
					str += format("Latin Squares {}, Atomic: {}, Totally symmetric: {}\n", m_nLS, m_atomicLS, m_symmetricLS);
				
				if (!param(t_timing_output_mode))
					str += format("Thread execution time = {} ms\n", clock() - m_iTime);
			}
			printf(str.c_str());
			if (pOutResult)
				*pOutResult += str;
		}
	}
	StatReportAfterThreadEnd(ResetStat, "Thread ended, processed", (int)nLoops, bFirstThread); // see stat.h to enable

	delete pResult;
	delete[] bResults;

	for (int i = 0; i < countof(pAutGroup); i++)
		delete pAutGroup[i];

#endif
#if COUNT_GET_ROW_CALLS && !USE_CUDA
	extern ll getRowCallsCalls;
	extern size_t totalWeighChange;
	static int nMatr;
	static ll cntrTotal;
	printf("Matr# %4d: ********** cntr = %lld  = %lld  totalWeighChange = %zd\n", ++nMatr, getRowCallsCalls, cntrTotal += getRowCallsCalls, totalWeighChange);
	getRowCallsCalls = 0;
#endif
	return nLoops;
}
