﻿#pragma once
#include <fstream>
#include <iostream> 

#include <filesystem>
#include <cstring>
#include <SRGsupport.h>
using namespace std;

#pragma execution_character_set("utf-8")

#define SRG_CSV	"/SRG.csv"

SrgSummary::SrgSummary(const string* logFolder, int iMode, const string* extFile) {
	mode = iMode;
	if (!mode)
		return;
	if ((!logFolder || !logFolder->length()) && (!extFile || !extFile->length())) {
		printfYellow("*** Warning: path to '%s' not defined (check 'CSV_FileName' and/or 'ResultFolder')\n", SRG_CSV);
		printfYellow("***          can't save SRG values\n");
		mode = 0;
		return;
	}
	inpFile = "";
	if (mode == 1) {
		if (extFile && extFile->length() > 0)
			inpFile = *extFile;
		else if (logFolder && logFolder->length() > 0)
			inpFile = *logFolder + SRG_CSV;
	}
	tmpFile = *logFolder + SRG_CSV + "_tmp";
	outFile = *logFolder + SRG_CSV;
	outFile2 = extFile ? *extFile : *logFolder + SRG_CSV;
}

void SrgSummary::outSRG_info(int v, const SRGParam* graphParam, t_graphType graphType, int rank3, UInt grOrder, int srcGroupSize, int srcGroups, int srcAut) {
	if (!mode)
		return;

	FILE* fInp = 0, * fTmp = 0, * fOut = 0, * fOut2 = 0;
	if (mode == 1) {
		fInp = _fsopen(inpFile.c_str(), "r", _SH_DENYNO);
		if (!fInp)
			inpFile = "";
	}
	fopen_s(&fTmp, tmpFile.c_str(), "w");
	if (!fTmp) {
		printfRed("*** Error: Can't open temporary file '%s' to save SRG summary\n", tmpFile.c_str());
		exit(1);
	}

	char buf[1024], bufInp[1024];
	if (fInp)
		fgets(bufInp, sizeof(bufInp), fInp);

	fprintf(fTmp, "%s", "v,k,λ,μ,α,β,Rank 3,kc,λc,μc,Aut(G),Group Size,Number of Groups,Src Aut(M)\n");

	const auto k = graphParam->k;
	const auto λ = graphParam->λ;
	const auto μ = graphParam->μ;
	// form new row in 'buf'
	char* pBuf = buf;
	SPRINTFD(pBuf, buf, "%d,%d,%d,%d,", v, k, λ, μ);

	if (graphType == t_4_vert)
		SPRINTFD(pBuf, buf, "%d,%d", graphParam->α, graphParam->β);
	else
		SPRINTFD(pBuf, buf, "n/a,n/a");

	const auto rank2Symb = rank3 == 1 ? '+' : (rank3 ? '-' : ' ');
	const auto v_2k = v - 2 * k;
	SPRINTFD(pBuf, buf, ",%c,%d,%d,%d,", rank2Symb, v - k - 1, v_2k + μ - 2, v_2k + λ);
	if (grOrder != -1)
		SPRINTFD(pBuf, buf, ORDER_FRMT("", ""), GR_ORDER(grOrder));

	SPRINTFD(pBuf, buf, ",%d,%d,%d\n", srcGroupSize, srcGroups, srcAut);

	// merge (if requested) new row with existing SRG_CSV
	bool bNewRowRecorded = false;
	int vOld = -1, kOld = -1;
	while (1) {
		char* pStr = fInp ? fgets(bufInp, sizeof(bufInp), fInp) : NULL;
		if (!bNewRowRecorded) {
			if (pStr && strcmp(buf, bufInp) == 0) {
				// new row is the same as current row from SRG_CSV, ignore new row
				bNewRowRecorded = true;
			}
			else {
				if (pStr)
					sscanf_s(bufInp, "%d,%d", &vOld, &kOld);
				if (!pStr || vOld > v || (vOld == v && kOld > k)) {
					fprintf(fTmp, buf);
					bNewRowRecorded = true;
				}
			}
		}
		if (!pStr)
			break;
		fputs(bufInp, fTmp);
	}

	FCLOSE_F(fInp);
	FCLOSE_F(fTmp);

	copyFiles(tmpFile, outFile);
	copyFiles(tmpFile, outFile2);
	deleteFile(tmpFile);
}
void SrgSummary::deleteFile(const string& tmp)
{
	if (tmp.length()) {
		try {
			if (filesystem::remove(tmp)) {
				cout << "File deleted successfully: " << tmp << endl;
			}
			else {
				printfRed("File not found or could not be deleted: %s\n", tmp.c_str());
			}
		}
		catch (const filesystem::filesystem_error& e) {
			printfRed("Error deleting file: %s\n",e.what());
		}
	}
}
void SrgSummary::copyFiles(const string& inp, const string& out)
{
	if (inp.length() && out.length()) {
		filesystem::path source_path = inp;
		filesystem::path destination_path = out;

		try {
			filesystem::copy(source_path, destination_path, filesystem::copy_options::overwrite_existing);
			cout << "File copied successfully from " << source_path << " to " << destination_path << endl;
		}
		catch (const filesystem::filesystem_error& e) {
			printfRed("Error copying file: %s\n", e.what());
		}
	}
}
