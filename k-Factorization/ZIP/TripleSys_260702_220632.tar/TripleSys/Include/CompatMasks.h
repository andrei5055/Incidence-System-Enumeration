#pragma once
#include <vector>
#include "Intrinsics.h"
#include "Storage.h"


#define PRINT_PRECALC_SOLUTIONS			0
#define CHECK_GET_ROW					0
#define PRINT_MASK_SOLUTION_INTERVALS	0

#define COUNT_MASK_WEIGHT	0
#define OUT_MASK_WEIGHT		0

#define SAME_MASK_IDX		0			// We allow the same mask index to be used for three consecutive rows. 
// If 0, we will not apply the acceleration method that analyzes valid solutions for the remaining rows in such situations. 
#define UseSolutionCliques	!USE_CUDA	
										// The graph whose vertices are the remaining solutions must have a maximum 
										// clique whose size is equal to the number of unconstructed rows of the matrix.

#if PRINT_PRECALC_SOLUTIONS 
#define OUTPUT_PRECALC_SOLUTION(num_obj, pSol, pFileName)	outputPrecalcSolution(num_obj, pSol, pFileName)
#else
#define OUTPUT_PRECALC_SOLUTION(...)
#endif

#include "CompSolGraph.h"

class alldata;

class CCompatMasks {
	typedef uint& (CCompatMasks::* solutionInterval)(uint* pRowSolutionIdx, uint* pLast, ll availablePlayers) const;
public:
	CCompatMasks(const kSysParam* pSysParam, const alldata* pAllData);
	virtual ~CCompatMasks();
	static void initBitsInByteTable();
	CC inline auto numSolutionTotalB() const				{ return m_numSolutionTotalB; }
	CC inline tmask* getSolutionMask(uint solNumb = 0) const{ return rowsCompatMasks() + (solNumb + m_solAdj) * lenSolutionMask(); }
	CC inline auto numLongs2Skip(int iRow) const			{ return m_pNumLongs2Skip[iRow]; }
	CC inline const auto rowSolutionMasksIdx() const		{ return m_pRowSolutionMasksIdx; }
	CC inline auto numDaysResult() const					{ return m_numDaysResult; }
	CC inline auto numPreconstructedRows() const			{ return m_numPreconstructedRows; }
	CC inline void reset()									{ m_numObjects = 0; }
	CC inline auto getNumSolution() const					{ return m_numObjects; }
	CC inline const auto rowSolutionMasks() const			{ return m_pRowSolutionMasks; }
	CC inline auto maskTestingCompleted() const				{ return m_pMaskTestingCompleted; }
	CC void releaseSolMaskInfo();
	inline void releaseCompatMaskMemory()					{ delete[] rowsCompatMasks(); }
	CC inline auto selectPlayerByMask() const				{ return m_bSelectPlayerByMask; }
	CC inline auto numPlayerSolutionsPtr() const			{ return m_pPlayerSolutionCntr; }
	inline auto lenSolutionMask() const						{ return m_lenSolutionMask; }   // number of tmask's
	CC void initRowUsage(tmask** ppCompatibleSolutions, bool fullMatrix, bool* pUsePlayersMask, ll* pAvailablePlayerMask = NULL) const;
	CC inline uint& getSolutionInterval(uint* pRowSolutionIdx, uint* pLast, ll availablePlayers) const {
		return (this->*m_fSolutionInterval)(pRowSolutionIdx, pLast, availablePlayers);
	}
	CC uint countMaskFunc(const tmask* pCompatibleSolutions, size_t numMatrRow = 1, int bytes2skeep = 0, uint prevWeight = 0) const;
	CC uint getSolutionRange(uint& last, ll& availablePlayers, int i) const;
	virtual uint solutionIndex(uint idx) const				{ return idx; }
	virtual ctchar* getSolution(uint idx) const				{ return NULL; }
	CC inline const auto numRecAdj() const					{ return m_numRecAdj; }
	CC inline auto numPlayers() const						{ return m_numPlayers; }
	inline auto rowsCompatMasks() const						{ return m_pRowsCompatMasks; }
	inline auto availablePlayerMaskPntr(int idx = 0) const	{ return rowsCompatMasks() + (idx + 1) * lenSolutionMask() - 1; }
	CC inline auto useFeature(featureFlags mask) const		{ return sysParam()->useFeature(mask); }
	CC inline const kSysParam* sysParam() const				{ return m_pSysParam; }
	inline auto compatibleSolutions() const					{ return m_pCompatSolutions; }
	inline auto compatibleSolutionsPntr() const				{ return &m_pCompatSolutions; }
	inline const auto allData() const						{ return m_pAllData; }
	inline auto numMasks() const							{ return m_numMasks; }
	CC inline const auto getPlayersMask(int idx = 0) const	{ return m_playersMask[0]; }

#if !USE_64_BIT_MASK
	CC inline auto firstOnePosition(tchar byte) const { return m_FirstOnePosition[byte]; }
private:
	tchar m_FirstOnePosition[256]; // Table for fast determination of the first 1's position in byte.
#endif
protected:
	int setNumMasks();
	void initMaskMemory(uint numSolutions, int numMasks = 0, int numRecAdj = 0, int numSolAdj = 0);
	inline void setNumSolutions(uint numSol)				{ m_numSolutionTotal = numSol; }
	inline auto numSolutions() const						{ return m_numSolutionTotal; }
	inline void resetSolutionMask(uint idx) const			{ memset(rowsCompatMasks() + lenSolutionMask() * idx, 0, numSolutionTotalB()); }
	void setPlayersMask(ll mask)							{ m_playersMask[0] = m_playersMask[1] = mask; }
	CC inline void updatePlayersMask(ll val)				{ m_playersMask[1] &= val; }
	CC inline const auto lastInFirstSet() const				{ return m_lastInFirstSet; }
	inline void setLastInFirstSet(uint val)					{ m_lastInFirstSet = val; }
	inline auto lenDayResults() const						{ return m_lenDayResults; }
	void setNumRecAdj(int val)								{ m_numRecAdj = val; }
	CC inline auto setNumSolution(uint val)					{ m_numObjects = val; }
	inline auto solAdj() const								{ return m_solAdj; }
	void resetSolMaskIndices(bool resetSolutionForPlaers = true);
	void outputPrecalcSolution(int num_obj, ctchar* pSol, const char* pFileName) const;
	CC void defineSolutionIntervals();
	int setNumLongs2Skip(bool adjustRecCounter = false);
	void defineMask4SolutionIntervals(int nRow, unsigned int last);
	CC inline unsigned long minBit(ll availablePlayers) const {
#if USE_64_BIT_MASK
		unsigned long iBit;
		_BitScanForward64(&iBit, availablePlayers);
		return iBit;
#else
		return this->firstOnePosition(availablePlayers);
#endif
	}
private:
protected:
	uint m_numSolutionTotal;
	uint* m_pPlayerSolutionCntr = NULL;

	uint m_numObjects;
private:
	CC uint& solutionInterval2(uint* pRowSolutionIdx, uint* pLast, ll availablePlayers) const;
	CC uint& solutionInterval3(uint* pRowSolutionIdx, uint* pLast, ll availablePlayers) const;
	void releaseCompatibleSolutionMasks();
	void initSolMaskIndices();

	const int m_numPlayers;
	const int m_numPreconstructedRows;     // Number of preconstructed matrix rows
	const int m_numDaysResult;
	const bool m_bSelectPlayerByMask;      // Find players by mask of unused players
	const kSysParam* m_pSysParam;
	const alldata* m_pAllData;

	uint m_numSolutionTotalB;			   // length of one solution mask in bytes
	uint m_lenSolutionMask = 0;			   // length of one solution mask in tmask units 
	uint m_numMasks;
	uint m_lastInFirstSet;
	int m_lenDayResults;
	int m_solAdj = 0;
	int m_numRecAdj = 0;

	// For each row of the matrix, we define two masks, each containing an interval of consecutive bits set to 1
	// These intervals represent the row's first and last sets of solutions that lie outside the separately tested 64-bit intervals.
	tmask* m_pRowSolutionMasks = NULL;
	//  ... and the the set of indices of the long long elements which corresponds to two mask's sets.                           
	uint* m_pRowSolutionMasksIdx = NULL;
	tmask* m_pRowsCompatMasks = NULL;
	bool* m_pMaskTestingCompleted = NULL;
	uint* m_pNumLongs2Skip = NULL;			// Pointer to the number of long long's that we don't need to copy for each row.

	tmask* m_pCompatSolutions = NULL;
	solutionInterval m_fSolutionInterval;
	ll m_playersMask[2] = { 0, 0 };		   // Mask with bits corresponding to players from first group of predefined rows equal to zeros.
	static tchar m_pBitsInByte[256];	   // Table for fast counting of bits in byte
};

class CCompressedMask : public CCompatMasks {
public:
	CCompressedMask(const kSysParam* pSysParam, const alldata* pAllData) : CCompatMasks(pSysParam, pAllData) {}
	~CCompressedMask()							{ releaseSolIndices(); }
	void compressCompatMasks(tmask* pCompSol, const CCompatMasks* pCompMask, uint solIdx);
	virtual uint solutionIndex(uint idx) const	{ return *(solIndices() + idx); }
private:
	inline auto solIndices() const				{ return m_pSolIdx; }
	inline void releaseSolIndices()	const		{ delete[] solIndices(); }

	uint* m_pSolIdx = NULL;					// Indices of the solutions stored in compressed mask
};