#pragma once
#include <vector>
#include "k-SysSupport.h"

#define nPlayers  21
#define GroupSize 3

// The maximum numbers of players and groups per day for which the program is compiled.
#define MAX_PLAYER_NUMBER			92
#define MAX_GROUP_NUMBER			(MAX_PLAYER_NUMBER / 2)

#define MAX_CYCLE_SETS		32
#define MAX_CYCLES_PER_SET	(MAX_PLAYER_NUMBER / 4)
#define USE_GROUP_4_2_ROWS   0  // The use of the Aut(M) of the 2-row matrix
#define MAX_PRECALC_ROWS     4

#define unset ((tchar)(-1))

typedef enum {
	t_nonregular = 0,
	t_regular = 1 << 0,
	t_srg = t_regular + (1 << 1),
	t_4_vert = t_srg + (1 << 2),
	t_triangular,
	t_rock,
	t_quasi_srg,
	t_complete = -1
} t_graphType;

typedef enum {
	// indices of parameters with the integer type values
	t_numPlayers,
	t_numPlayersMax,
	t_groupSize,
	t_CBMP_Graph,			// Complete Balanced Multi-Partite Graph
	t_generateMatrixExample,
	t_u1f,
	t_use2RowsCanonization,
	t_useFastCanonizerForG2,
	t_submatrixGroupOrderMin,
	t_resultGroupOrderMin,
	t_useGPU,
	t_MultiThreading,
	t_numThreads,
	t_numKThreads,
	t_numGThreads,
	t_nRowsInStartMatrix,
	t_nRowsInResultMatrix,
	t_nMaxNumberOfStartMatrices,
	t_nFirstIndexOfStartMatrices,
	t_expectedResult,
	t_useCheckLinksV,
	t_useRowsPrecalculation,
	t_useSolutionCliquesAfterRow,
	t_lastRowSecondPlayer,
	t_printMatrices,
	t_savingMatricesToDisk,
	t_matrixCanonInterval,
	t_checkConstructedMatrices,
	t_useSS,
	t_p1f_counter,
	t_autLevelMinDef,
	t_autLevelMaxDef,
	t_autLevelMin,
	t_autLevelMax,
	t_autDirection,
	t_autGroupNumb,
	t_autSaveTestedTrs,
	t_useImproveMatrix,
	t_useCombinedSolutions,
	t_out_CSV_file,
	t_outAutomorphismGroup,
	t_nestedGroups,
	t_gridSize,
	t_blockSize,
	t_orderMatrices,
	t_allowUndefinedCycles,
	t_any2RowsConvertToFirst2,
	t_exploreMatrices,
	t_constructLatticeGraphs,
	t_semiSymmetricGraphs,
	t_rejectCycleLength,
	t_test,
	t_keepPrevResult,
	t_saveLatinSquareType,
	t_inputLatinSquareType,
	t_v4, t_v4B, t_v4C, t_v4D,
	t_v4Row, t_v4RowB, t_v4RowC, t_v4RowD,
	t_useCompatibilityCheck,
	t_halfRowMode,
	t_useKSolve,
	t_useZStabilizer,
	t_timing_output_mode,
	t_CanonizeInput,
	t_lastParam,
	// Indices of parameters with the int* type values
	t_v4Array = 0,
	t_numCommonNeighbors,
	t_lastIntArryParam,
	// indices of parameters with the string type values
	t_UFname = 0,
	t_StartFolder,
	t_ResultFolder,
	t_ImprovedResultFolder,
	t_binaryCanonizer,
	t_testName,
	t_matrTest, // parameter, which will define the test to be launched for constructed matrix or matrices
	t_CSV_FileName,
	t_ResultsName,
	t_InputDataFileName,
	t_lastStrParam,
} paramID;

typedef enum {
	t_intValue,
	t_intArray,
	t_strValue,
	t_strArray,
} t_ParamType;

typedef enum {
	t_noTest = 0,
	t_ShortestCyclesFirst = 1 << 3,
	t_useCompressedMasks = 1 << 8,
} featureFlags;

typedef enum {
	t_printNothing = 0,
	t_printLoadedMatrices = -1 << 1,
	t_printRejectionReason = 1 << 1,
	t_printTransformed = 1 << 4,
	t_printExploringSRG = 1 << 6,   // report the process of SRG's exploring 
} printFlags;

typedef struct {
	const char** paramNames;
	int numParams;
	std::vector<int>* m_pTmpParamStorage;
} paramDescr;

class kSysParam {
public:
	kSysParam()				{ Init(NULL); }
	kSysParam(const kSysParam* param) {
		*this = *param;
		Init(param->u1fCycles[0]);
	}
	~kSysParam()			{ 
		if (m_b_dataOwner) {
			delete[] u1fCycles[0];
			u1fCycles[0] = NULL;
		}
	}
	CC inline auto paramVal(paramID id) const { return val[id]; }
	CC inline bool useFeature(featureFlags msk) const 
											{ return val[t_test] & msk; }
	CC inline auto partiteNumb() const		{ return val[t_CBMP_Graph]; }
	CC inline auto completeGraph() const	{ return partiteNumb() == 1; }
	inline auto partitionSize() const		{ return val[t_numPlayers] / partiteNumb(); }
	CC inline auto numFactors() const		{ return m_numFactors; }
	CC inline auto numGroups() const		{ return val[t_numPlayers] / val[t_groupSize]; }
	void setup();

	int val[t_lastParam];
	int groupSizeFactorial;
	int m_numFactors;
	std::string* strVal[t_lastStrParam];
	int* arrVal[t_lastIntArryParam];
	tchar* u1fCycles[1];
	paramDescr* pParamDescr;
private:
	void Init(ctchar* pU1fCycles) {
		pParamDescr = NULL;
		memset(strVal, 0, sizeof(strVal));
		memset(arrVal, 0, sizeof(arrVal));
		if (m_b_dataOwner = (pU1fCycles != NULL)) {
			const auto len = 1 + *pU1fCycles * MAX_CYCLES_PER_SET;
			u1fCycles[0] = new tchar[len];
			memcpy(u1fCycles[0], pU1fCycles, len);
		}
		else
			u1fCycles[0] = NULL;
	}
	bool m_b_dataOwner;
};


#define FORMAT_SPEC(TYPE, ...) \
    "%" __VA_OPT__(__VA_ARGS__) TYPE

#define ORDER_FRMT_END(ENTRY_FRMT, END_FRMT, ...) \
    FORMAT_SPEC(ENTRY_FRMT, __VA_ARGS__) " " END_FRMT

#define ORDER_PRINT_FRMT(START_FRMT, ENTRY_FRMT, END_FRMT, ...) \
    START_FRMT " " ORDER_FRMT_END(ENTRY_FRMT, END_FRMT, __VA_ARGS__)

#define USE_INT128 1
#if USE_INT128
#include "UInt128.h"
#define UInt UInt128
#define ORDER_FRMT(START_FRMT, END_FRMT,...) \
	ORDER_PRINT_FRMT(START_FRMT, "s", END_FRMT, __VA_ARGS__)
#define GR_ORDER(order)		order.toString().c_str()
#define TO_STRING(x) x.toString()
#else
#define UInt size_t
#define ORDER_FRMT(START_FRMT, END_FRMT,...) \
	ORDER_PRINT_FRMT(START_FRMT, "zu", END_FRMT, __VA_ARGS__)
#define GR_ORDER(order)		order
#define TO_STRING(x) std::to_string(x)
#endif

#define SECTION_PARAM_MAIN		"Main parameters:"
#define SECTION_PARAM_ARRAY     "Array type parameters:"
#define SECTION_PARAM_STRINGS	"String type parameters:"
#define SECTION_PARAM_U1F_CONF	"U1F configurations:"
