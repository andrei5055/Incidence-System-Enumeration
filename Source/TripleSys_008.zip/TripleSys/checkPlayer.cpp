#include <iostream>
#include "TripleSys.h"
/**
inline char alldata::checkPlayer(char* v, char* l, char id, char ip, char iv )
{
	switch (id) {
	case 0: return iv;
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	}**/
