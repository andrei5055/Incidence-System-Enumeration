
template<typename T>
void outMatrix(const T* c, int nl, int nc, int np, int ns, FILE* f, bool makeString, bool toScreen, int cntr=-1, const unsigned char* pDayPerm=NULL) {
	char buffer[512];
	const auto* endLine = makeString ? " \"\n" : "\n";
	for (int j = 0; j < nl; j++) {
		char* pBuf = buffer;
		SPRINTFD(pBuf, buffer, " \"");
		for (int i = 0; i < nc; i++, c++) {
			if (np && !(i % np))
				SPRINTFD(pBuf, buffer, " ");

			if (*c == -1 && !f)
				printfGreen(" %3d", *c);
			else
				SPRINTFD(pBuf, buffer, " %3d", *c);
		}

		if (cntr < 0) {
			if (j + 1 >= nl || ns <= 0 || ((j + 1) % ns) == 0)
				SPRINTFD(pBuf, buffer, endLine);
			else
				SPRINTFD(pBuf, buffer, " ");
		}
		else {
			if (cntr)
				SPRINTFD(pBuf, buffer, "\":  day =%2d\n", pDayPerm[j]);
			else
				SPRINTFD(pBuf, buffer, "\"\n");
		}

		_printf(f, toScreen, buffer);
	}
}

template<typename T>
class Table {
public:
	Table(char const *name, int nl, int nc, int ns = 0, int np = GroupSize, bool makeString = false, bool outCntr = false) :
		m_name(name), m_nl(nl), m_nc(nc), m_ns(ns), m_np(np), 
		m_makeString(makeString), m_bOutCntr(outCntr) {}
	void printTable(const T *c, bool outCntr = false, const char *fileName = NULL);
	inline void addCounterToTableName(bool val) { m_bOutCntr = val; }
private:
	const char *m_name;
	const int m_nl;
	const int m_nc;
	const int m_ns;
	const int m_np;
	const bool m_makeString;
	bool m_bOutCntr;          // When true, the counter will be added to the Table Name
public:
	int m_cntr = 0;
};

static size_t nMatr = 0;
static size_t nMatrMax = 0;
unsigned char *pMatrixStorage = NULL;

template<typename T>
void Table<T>::printTable(const T *c, bool outCntr, const char *fileName)
{
	char buffer[512], *pBuf = buffer;
	FOPEN_F(f, fileName, m_cntr ? "a" : "w");
	const auto* endLine = m_makeString ? " \"\n" : "\n";
	if (outCntr)
		m_cntr++;

	if (m_name && strlen(m_name) != 0) {
		if (outCntr && m_bOutCntr)
			SPRINTFD(pBuf, buffer, "%s %d:\n", m_name, m_cntr);
		else
			SPRINTFD(pBuf, buffer, "%s:\n", m_name);
	}

	_printf(f, true, buffer);
	outMatrix(c, m_nl, m_nc, m_np, m_ns, f, m_makeString, true);
#if OUTPUT_VECTOR_STAT
	// Output of a vector with the i-th coordinate equal to the number  
	// of appearances of the i-th player first player in the group.
	if (m_cntr) {
		auto buf = new unsigned char [m_nc];
		memset(buf, 0, m_nc * sizeof(*buf));
		const auto lenMatr = m_nl * nGroups;
		auto matrix = new unsigned char[lenMatr];
		auto pntr = c;
		for (T i = 0; i < m_nl; i++, pntr += m_nc) {
			auto pMatrixRow = matrix + nGroups * i;
			for (T j = 0; j < nGroups; j++)
				buf[pMatrixRow[j] = pntr[j*m_np]]++;
		}

		for (size_t i = 0; i < nMatr; i++) {
			if (memcmp(matrix, pMatrixStorage + lenMatr * i, lenMatr))
				continue;

			delete[] matrix;
			matrix = NULL;
			break;
		}

		if (matrix) {
			// New matrix found
			if (nMatr == nMatrMax) {
				auto pTmp = pMatrixStorage;
				nMatrMax = 2 * (nMatrMax + 1);
				pMatrixStorage = new unsigned char[nMatrMax * lenMatr];
				if (pTmp) {
					memcpy(pMatrixStorage, pTmp, nMatr * lenMatr);
					delete[] pTmp;
				}
			}

			memcpy(pMatrixStorage + nMatr++ * lenMatr, matrix, lenMatr);
			delete[] matrix;
		}

		static char idx[256] = { '\0' };
		pBuf = idx;
		if (idx[0] == '\0') {
			for (T i = 0; i < m_nc; i++)
				SPRINTFD(pBuf, idx, " %2d:", i);

			SPRINTFD(pBuf, idx, "\n");
		}

		pBuf = buffer;
		for (T i = 0; i < m_nc; i++)
			SPRINTFD(pBuf, buffer, " %3d", buf[i]);

		delete[] buf;
		SPRINTFD(pBuf, buffer, "\n");
		_printf(f, false, idx);
		_printf(f, false, buffer);

		if (m_nc == 15 && m_cntr == 101) {
			auto pntr = pMatrixStorage;
			for (size_t i = 0; i < nMatr; i++, pntr += lenMatr) {
				pBuf = buffer;
				SPRINTFD(pBuf, buffer, "\nMatrix #%zd\n", i);
				auto ptr = pntr;
				for (T i1 = 0; i1 < m_nl; i1++, ptr += nGroups) {
					for (T j = 0; j < nGroups; j++)
						SPRINTFD(pBuf, buffer, " %3d", ptr[j]);
					SPRINTFD(pBuf, buffer, "\n");
				}

				_printf(f, false, buffer);
			}

			delete[] pMatrixStorage;
			nMatr = nMatrMax = 0;
		}
	}
#endif
	FCLOSE_F(f);
}

